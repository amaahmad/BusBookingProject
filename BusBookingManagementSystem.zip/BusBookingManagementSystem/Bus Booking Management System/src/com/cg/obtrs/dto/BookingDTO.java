package com.cg.obtrs.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BookingDTO {
	private int busId;
    private String passengerNames[];
	private Integer seatsBooked;
	
	public BookingDTO()
	{
		
	}
	
	
	public BookingDTO(int busId, String[] passengerNames, Integer seatsBooked) {
		super();
		this.busId = busId;
		this.passengerNames = passengerNames;
		this.seatsBooked = seatsBooked;
	}


	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	
	public Integer getSeatsBooked() {
		return seatsBooked;
	}
	
	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}
	public String[] getPassengerNames() {
		return passengerNames;
	}
	public void setPassengerNames(String[] passengerNames) {
		this.passengerNames = passengerNames;
	}
	

}