package com.cg.obtrs.ui;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import com.cg.obtrs.dao.StaticDb;
import com.cg.obtrs.dto.CustomerDTO;
import com.cg.obtrs.exception.CustomException;
import com.cg.obtrs.service.BookingService;
import com.cg.obtrs.service.BookingServiceImpl;
import com.cg.obtrs.service.CustomerService;
import com.cg.obtrs.service.CustomerServiceImpl;

public class Starter {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int mainScreenFlag=1;
		CustomerService custService = new CustomerServiceImpl();
		BookingService bookingService = new BookingServiceImpl();
		while (mainScreenFlag > 0) {
			System.out.println("************************ONLINE BUS TICKET RESERVATION SYSTEM***********************");
			System.out.println("1.Admin");
			System.out.println("2.User");
			int choice = input.nextInt();

			switch (choice) {
			case 1:
				break;
			case 2:
				System.out.println("1.User Sign Up");
				System.out.println("2.User Login in");
				int custChoice = input.nextInt();
				switch (custChoice) {
				case 1:
					System.out.println("Enter Username");
					String userName = input.next();
					System.out.println("Enter Password");
					String password = input.next();
					System.out.println("Enter your Name");
					String name = input.next();
					System.out.println("Enter Phone number");
					long phoneNo = input.nextLong();
					System.out.println("Enter Email ID");
					String email = input.next();
					Random random = new Random();
					int custId = random.nextInt(1000);
					System.out.println(custService
							.customerSignUp(name, phoneNo, email, custId, userName, password));
					System.out.println("Sign In to Continue......");
				case 2:
					System.out.println("Please Enter Username");
					userName = input.next();
					System.out.println("Please Enter Password");
					password = input.next();
					try {
						System.out.println(custService.customerLoginIn(userName, password));
					} catch (CustomException e1) {
						System.out.println(e1.getMessage());
					}
					
					System.out.println("1.Change Password");
					System.out.println("2.Search for Bus");
					int loginChoice = input.nextInt();
					switch (loginChoice) {
					case 1:
						System.out.println("Enter Your EmailID");
						String customerEmail = input.next();
						System.out.println("Enter currentPassword");
						String currentPassword = input.next();
						System.out.println("Enter New Password");
						String newPassword = input.next();
						try {
							boolean flag = custService.changePassword(customerEmail, currentPassword, newPassword);
							if (flag == true) {
								System.out.println("Password change successfully");
							}
						} catch (CustomException e) {
							e.printStackTrace();
						}
						break;
					case 2:
						System.out.println("Enter Source Station");
						String sourceStation = input.next();
						System.out.println("Enter Destination Station");
						String destinationStation = input.next();
						try {
							System.out.println(custService.searchBus(sourceStation, destinationStation));
							System.out.println("Enter BusId to continue....");
							int busId = input.nextInt();
							System.out.println("1.Display Fare");
							System.out.println("2.Check Seat Availability");
							int seatChoice = input.nextInt();
							switch (seatChoice) {
							case 1:
								System.out.println("Enter your Age");
								int passengerAge = input.nextInt();
								System.out.println("Discount Fare for selected Bus=" + "Rs."
										+ bookingService.displayFare(passengerAge, busId));
								break;
							case 2:
								System.out.println(
										"Number of seats available =" + custService.checkSeatAvailability(busId));
								System.out.println("1. Book a Seat");
								int bookingChoice = input.nextInt();
								switch (bookingChoice) {
								case 1:
									System.out.println("Enter Number of seats to book");
									int noOfBookingSeats = input.nextInt();
									int totalFare=0;
									ArrayList<String> passengerNames = new ArrayList<>();
									for(int i=1;i<=noOfBookingSeats;i++)
									{
										System.out.println(i+ "Passenger Name");
										passengerNames.add(input.next());
								        System.out.println(i+ "Passenger Age");
										passengerAge = input.nextInt();
										totalFare += bookingService.displayFare(passengerAge, busId);
									}
									System.out.println("Total Fare will be"+totalFare);
									System.out.println("Enter Debit or Credit Card Number");
									long cardNumber= input.nextLong();
									System.out.println("Enter CVV");
									byte cardCvv=input.nextByte();
									System.out.println(bookingService.bookSeat(passengerNames,cardNumber,cardCvv,busId));
									System.out.println("1.Generate Ticket");
									System.out.println("2.Cancel Booking");
									int ticketChoice = input.nextInt();
									switch (ticketChoice) {
									case 1:
										System.out.println("Enter your booking Id");
										int bookingId = input.nextInt();
										System.out.println(bookingService.generateTicket(busId, bookingId));
										break;
									case 2: System.out.println("Enter Booking Id");
									         int passengerBookingId = input.nextInt();
									    System.out.println(bookingService.cancelBooking(passengerBookingId, busId));     
									}
								}
							}
						} catch (CustomException e) {
							System.out.println(e);
						}
					}

				}
			}
		}

	}
}
