import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Booking } from '../common/booking';
import { Bus } from '../common/bus';
import {BookingDetails} from '../bookingdetails';

@Component({
  selector: 'app-ticketgeneration',
  templateUrl: './ticketgeneration.component.html',
  styleUrls: ['./ticketgeneration.component.css']
})
export class TicketgenerationComponent implements OnInit
 {
  ticketdetailsflag = false;
  ticketgenerationflag = false;
  bus : Bus[];
  booking : Booking;
  bookingdetails : BookingDetails[] = [];
  busObj : Bus;
 ticketgenerationform = new FormGroup({
   bookingId : new FormControl('')
 })
  constructor(private bookingservice : BookingService) { }

  ngOnInit(): void 
  {
    this.bookingservice.getBus().subscribe((bus)=>
    {
      this.bus = bus;
    });
  }

  generateTicket()
  {
     let bookingId = this.ticketgenerationform.get('bookingId').value;
     this.bookingservice.getBookingById(bookingId).subscribe((booking)=>
     {
       this.booking = booking;
     })
     console.log(this.booking);
     this.ticketgenerationflag = true;
 
  }
  showTicket()
  { 
    let passengerNames: string = "";
   
  // console.log(this.booking.bookingId);
  // console.log(this.booking.busId);
  // console.log(this.booking.seatsBooked);
  // console.log(this.booking.totalFare);
  // console.log(this.booking.seatNo);
  // console.log(this.booking.passengerNames);

  for(let i=0;i<this.booking.seatsBooked;i++)
  {
     passengerNames = passengerNames +","+this.booking.passengerNames[i];
  }
  this.ticketdetailsflag = true;
  for(let i=0;i<this.bus.length;i++)
  {
    if(this.bus[i].busId==this.booking.busId)
    {
      this.busObj = this.bus[i];
      break;
    }
  }

  let bookingdetailobj= new BookingDetails(this.booking.busId, passengerNames,this.booking.seatsBooked, this.booking.totalFare, this.booking.bookingId, this.booking.seatNo, this.busObj.sourceStation, this.busObj.destinationStation, this.busObj.boardingTime, this.busObj.dropTime, this.busObj.busType);
  this.bookingdetails.push(bookingdetailobj);

 console.log(this.bookingdetails);
 
  }  
}
