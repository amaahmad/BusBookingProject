import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Booking} from '../common/booking';
import { BookingService } from '../booking.service';
import { Bus } from '../common/bus';

@Component({
  selector: 'app-bookingpage',
  templateUrl: './bookingpage.component.html',
  styleUrls: ['./bookingpage.component.css']
})
export class BookingpageComponent implements OnInit 
{
  bookingConfirmFlag = false;
  passengerNames = [];
  bus : Bus[];
  bookingId:number;
  bookingform = new FormGroup({
    busId: new FormControl(''),
    numberOfPassengers : new FormControl(''),
    passengerName1 : new FormControl(''),
    passengerName2 : new FormControl(''),
    passengerName3 : new FormControl(''),
    passengerName4 : new FormControl(''),
    passengerAge : new FormControl(''),
    phoneNumber : new FormControl('')
  })

  constructor(private bookingservice : BookingService) { }

  ngOnInit(): void 
  {
  this.bookingservice.getBus().subscribe((bus)=>
  {
    this.bus = bus;
  });
  }
  bookSeats()
  {
    let busfare;
   let busId = this.bookingform.get('busId').value;
   let numberOfPassengers = parseInt(this.bookingform.get('numberOfPassengers').value);
   for(let i=0;i<this.bus.length;i++)
   {
    
    if(this.bus[i].busId==busId)
    {
      busfare = this.bus[i].fare*numberOfPassengers;
   let seatsBooked = (this.bus[i].seatsBooked) + numberOfPassengers;
  let busupdate = new Bus(this.bus[i].busId, this.bus[i].sourceStation, this.bus[i].destinationStation, this.bus[i].boardingTime, this.bus[i].dropTime, this.bus[i].busType, this.bus[i].totalSeats, seatsBooked, this.bus[i].fare);
  this.bookingservice.updateBus(busupdate).subscribe((busupdate)=>
      { 
      console.log(busupdate);
      });
      break;
    }
   }
   let seatNo1="", seatNo2="", seatNo3="", seatNo4="";
    this.bookingId = Math.floor(Math.random() * 1000) + 1;
   let numOfPassenger = this.bookingform.get('numberOfPassengers').value;
   let passengerName1 = this.bookingform.get('passengerName1').value;
   let passengerName2= this.bookingform.get('passengerName2').value;
   let passengerName3 = this.bookingform.get('passengerName3').value;
   let passengerName4= this.bookingform.get('passengerName4').value;
   if(passengerName1!='')
   {
   this.passengerNames.push(passengerName1);
   seatNo1 = Math.floor(Math.random()*10)+1 +"A";
   }
   if(passengerName2!='')
   {
   this.passengerNames.push(passengerName2);
    seatNo2 = Math.floor(Math.random()*10)+1 +"B";
   }
   if(passengerName3!='')
   {
   this.passengerNames.push(passengerName3);
    seatNo3 = Math.floor(Math.random()*10)+1 +"A";
   }
   if(passengerName4!='')
   {
   this.passengerNames.push(passengerName4);
    seatNo4 = Math.floor(Math.random()*10)+1 +"A";
   }
   let allSeatsBooked = seatNo1+","+seatNo2+","+seatNo3+","+seatNo4;
  let phoneNumber = this.bookingform.get('phoneNumber').value;
  let booking = new Booking(busId, this.passengerNames, numOfPassenger,busfare,this.bookingId, allSeatsBooked);
  // console.log(busId+numOfPassenger+ this.passengerNames+phoneNumber);
  this.bookingservice.addBooking(booking).subscribe((booking)=>{
    console.log(booking);
    this.bookingConfirmFlag= true;    
  })

}
}
