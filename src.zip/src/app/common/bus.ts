export class Bus
{
    busId : number;
    sourceStation : string;
    destinationStation : string;
    boardingTime : string;
    dropTime : string;
    busType : string;
    totalSeats : number;
    seatsBooked : number;
    fare : number;


    constructor(busId, sourceStation, destinationStation, boardingTime, dropTime, busType, totalSeats, seatsBooked,fare)
    {
        this.busId = busId;
        this.sourceStation = sourceStation;
        this.destinationStation = destinationStation;
        this.boardingTime = boardingTime;
        this.dropTime = dropTime;
        this.busType = busType;
        this.totalSeats = totalSeats;
        this.seatsBooked = seatsBooked;
        this.fare =fare;
    }
}