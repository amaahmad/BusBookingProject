export class Booking
{
    busId : number;
    passengerNames: [];
    seatsBooked : number; 
    totalFare : string;
    bookingId : number;
    seatNo : string;

    constructor(busId, passengerNames, seatsBooked, totalFare, bookingId, seatNo)
    {
        this.busId = busId;
        this.passengerNames = passengerNames;
        this.seatsBooked = seatsBooked;
        this.totalFare = totalFare;
        this.bookingId = bookingId;
        this.seatNo = seatNo;
    }
}