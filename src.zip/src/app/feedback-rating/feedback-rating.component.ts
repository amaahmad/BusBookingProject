import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Booking } from '../Booking';

@Component({
  selector: 'app-feedback-rating',
  templateUrl: './feedback-rating.component.html',
  styleUrls: ['./feedback-rating.component.css']
})
export class FeedbackRatingComponent implements OnInit {
  flag1:boolean;
  constructor(private bookSer:BookingService,private router:Router) { }
  feedback = new FormGroup({
    bookingId: new FormControl(''),
    feedback: new FormControl(''),
    rating: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.bookSer.getBooking();
    }
  feedbackRating()
  {
  let BookingId = this.feedback.get('bookingId').value;
  let feedback=this.feedback.get('feedback').value;
  let rating=this.feedback.get('rating').value;
    console.log(this.bookSer.bookingDb.length);
    for(let i=0;i<this.bookSer.bookingDb.length;i++) 
    {
      if (this.bookSer.bookingDb[i].bookingId == BookingId)
      {     
        
            this.bookSer.bookingDb[i].feedBack=feedback;
            this.bookSer.bookingDb[i].rating=rating;

            let tempBooking:Booking=this.bookSer.bookingDb[i];
            this.bookSer.updateBooking(this.bookSer.bookingDb[i].id,tempBooking).subscribe(data=>{console.log(data)});
            this.bookSer.flag=true;
        
      }     
    }
    if (this.bookSer.flag) 
    {
      this.flag1=true;
    }
  }

}
