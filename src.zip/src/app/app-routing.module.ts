import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookingComponent } from './booking/booking.component';
import { BookingpageComponent } from './bookingpage/bookingpage.component';
import { AppComponent } from './app.component';
import { TicketgenerationComponent } from './ticketgeneration/ticketgeneration.component';
import { BookingcancelComponent } from './bookingcancel/bookingcancel.component';
import { HomepageComponent } from './homepage/homepage.component';


const routes: Routes = [
  {path: 'bookingpage', component: BookingpageComponent},
  {path: 'searchpage', component: BookingComponent},
  {path:'generateticket', component: TicketgenerationComponent},
  {path: 'cancelbooking', component: BookingcancelComponent},
  {path: 'homepage', component: HomepageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
