import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Booking } from './common/booking';
import { Bus } from './common/bus';
import {Http, Response, Headers,RequestOptions} from '@angular/http';
import { map} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookingService 
{
 booking : Booking;
 bus : Bus;
 private  bookingbaseUrl = "http://localhost:8080/api";
 private  busbaseUrl = "http://localhost:8080/api";
 private headers = new Headers({'Content-Type' : 'application/json'});
 private options  = new RequestOptions({headers: this.headers});

  constructor(private http : Http) { }


  getBus()
  {
    return this.http.get(this.busbaseUrl+'/bus').pipe(map((response : Response) => response.json()));
  } 
  updateBus(bus : Bus)
  {
    return this.http.put(this.busbaseUrl+'/update', JSON.stringify(bus) ,this.options).pipe(map((response : Response)=>response.json()));
  }
  getBooking()
  {
    return this.http.get(this.busbaseUrl+'/booking').pipe(map((response : Response) => response.json()));
  }
  addBooking(booking : Booking)
  {
    return this.http.post(this.bookingbaseUrl+'/add', JSON.stringify(booking) ,this.options).pipe(map((response : Response)=>response.json()));
  }

  getBookingById(id: number)
  {
    return this.http.get(this.busbaseUrl+'/booking'+id).pipe(map((response : Response) => response.json()));
  }
  
  deleteBooking(id: number)
  {
    return this.http.delete(this.busbaseUrl+'/delete'+id).pipe(map((response : Response) => response.json()));
  }

}
