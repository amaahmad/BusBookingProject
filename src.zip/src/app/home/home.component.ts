import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BusService } from '../bus.service';
import { FormGroup, FormControl} from '@angular/forms';
import { Bus } from '../Bus';

@Component
({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit 
{
  flagId:any;
  flagBoardingTime:any;
  flagDropTime:any;
  flagBusType:any;
  flagTotalSeat:any;
  flagFare:any;
  flagSeatBooked:any;

  flag1:any;
  id:any;
  bus:any[]=[];
  constructor(private busSer:BusService,private router:Router) { }
  searchBus = new FormGroup
  ({
    sourceStation: new FormControl(''),
    destinationStation: new FormControl('')
  });
  ngOnInit(): void 
  {
    this.busSer.getBus();
  }
  search()
  {
    let sourceStation = this.searchBus.get('sourceStation').value;
    let destinationStation = this.searchBus.get('destinationStation').value;
    let k=0;
    for(let i=0;i<this.busSer.busDb.length;i++) 
    {
      if (this.busSer.busDb[i].sourceStation == sourceStation&&this.busSer.busDb[i].destinationStation==destinationStation)
      {     
        this.bus[k++]=this.busSer.busDb[i];
        this.busSer.flag=true;
      }      
    }
    if (this.busSer.flag==true)
    {
      this.flag1=true; 
    }
    else
    {
      this.flag1=false;
    }
  }
  bookBus()
  {
    this.router.navigateByUrl("/busbooking");
  }
  sortByBusId()
  {
    if(this.flagId==false)
    {
      this.bus.sort((a,b)=>b.id-a.id);
      this.flagId=true;
    }
    else
    {
    this.bus.sort((a,b)=>a.id-b.id);
    this.flagId=false;
    }
  }
  sortByBoardingTime()
  {
    if(this.flagBoardingTime==false)
    {
      this.bus.sort((a,b)=>b.boardingTime.localeCompare(a.boardingTime));
      this.flagBoardingTime=true;
    }
    else
    {
      this.bus.sort((a,b)=>a.boardingTime.localeCompare(b.boardingTime));
      this.flagBoardingTime=false;
    }
  }
  sortByDropTime()
  {
    if(this.flagDropTime==false)
    {
      this.bus.sort((a,b)=>b.dropTime.localeCompare(a.dropTime));
      this.flagDropTime=true;
    }
    else
    {
      this.bus.sort((a,b)=>a.dropTime.localeCompare(b.dropTime));
      this.flagDropTime=false;
    }
  }
  sortByBusType()
  {
    if(this.flagBusType==false)
    {
      this.bus.sort((a,b)=>b.busType.localeCompare(a.busType));
      this.flagBusType=true;
    }
    else
    {
      this.bus.sort((a,b)=>a.busType.localeCompare(b.busType));
      this.flagBusType=false;
    }
  }
  sortByTotalSeat()
  {
    if(this.flagTotalSeat==false)
    {
      this.bus.sort((a,b)=>b.totalSeats-a.totalSeats);
      this.flagTotalSeat=true;
    }
    else
    {
      this.bus.sort((a,b)=>a.totalSeats-b.totalSeats);
      this.flagTotalSeat=false;
    }
  }
  sortByFare()
  {
    if(this.flagFare==false)
    {
      this.bus.sort((a,b)=>b.fare-a.fare);
      this.flagFare=true;
    }
    else
    {
      this.bus.sort((a,b)=>a.fare-b.fare);
      this.flagFare=false;
    }
  }
  sortBySeatBooked()
  {
    if(this.flagSeatBooked==false)
    {
      this.bus.sort((a,b)=>b.seatsBooked-a.seatsBooked);
      this.flagSeatBooked=true;
    }
    else
    {
      this.bus.sort((a,b)=>a.seatsBooked-b.seatsBooked);
      this.flagSeatBooked=false;
    }  
  }
}
