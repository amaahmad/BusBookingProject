import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Booking } from '../common/booking';
import { Bus } from '../common/bus';
import { Router } from '@angular/router';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  searchResultFlag = false;
  booking: Booking[];
  searchList: Bus[] = [];
  bus: Bus[];
  journeyDate: string;
  searchFlag = true;

  constructor(private bookingService: BookingService, public router: Router) { }

  ngOnInit(): void {
    this.listBooking();
    this.listBus();
  }
  listBooking() {
    this.bookingService.getBooking().subscribe((booking) => {
      this.booking = booking;
    }
    )
  }
  listBus() {
    this.bookingService.getBus().subscribe((bus) => {
      this.bus = bus;
    }
    )
  }

  searchBus(source, destination, date) {
    for (let i = 0; i < this.bus.length; i++) {
      if (source == this.bus[i].sourceStation && destination == this.bus[i].destinationStation) {
        this.journeyDate = this.bus[i].boardingTime.toString().substring(0, 10);
        console.log(this.journeyDate);
        console.log(date);
        if (date == this.journeyDate) {
          this.searchList.push(this.bus[i]);
          this.searchResultFlag=false;
        }

      }
    }
     if(this.searchList[0]==null)
     {
       this.searchResultFlag= true;
     }
  }
  bookSeats()
  {   
    this.searchFlag= false;
    this.router.navigate(['/bookingpage']);
  }
}