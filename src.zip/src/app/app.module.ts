import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { BookingService } from './booking.service';
import { BookingComponent } from './booking/booking.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HttpModule} from '@angular/http';
import { BookingpageComponent } from './bookingpage/bookingpage.component';
import { TicketgenerationComponent } from './ticketgeneration/ticketgeneration.component';
import { BookingcancelComponent } from './bookingcancel/bookingcancel.component';
import { HomepageComponent } from './homepage/homepage.component';

@NgModule({
  declarations: [
    AppComponent,
    BookingComponent,
    HeaderComponent,
    FooterComponent,
    BookingpageComponent,
    TicketgenerationComponent,
    BookingcancelComponent,
    HomepageComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpModule,
    ReactiveFormsModule
  ],
  providers: [BookingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
