import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Bus } from '../common/bus';
import { Booking } from '../common/booking';

@Component({
  selector: 'app-bookingcancel',
  templateUrl: './bookingcancel.component.html',
  styleUrls: ['./bookingcancel.component.css']
})
export class BookingcancelComponent implements OnInit {
  bus : Bus[];
  bookingIdFlag = false;
  bookingCancelFlag = false;
  booking : Booking;
  busObj : Bus;
  cancellationform = new FormGroup({
    bookingId : new FormControl('')
  })

  constructor(private bookingservice : BookingService) { }

  ngOnInit(): void 
  {
    this.bookingservice.getBus().subscribe((bus)=>
    {
      this.bus = bus;
    });
    
  }

  cancelBooking()
  {

    console.log(this.bus);
    let bookingId = parseInt(this.cancellationform.get('bookingId').value);
    this.bookingservice.getBookingById(bookingId).subscribe((booking)=>
    {
      this.booking = booking;
    })
    console.log(this.booking);

    if(this.booking==null)
      this.bookingIdFlag = true;
     
      else
      {
      this.bookingIdFlag = false;
      this.bookingCancelFlag = true;
    this.bookingservice.deleteBooking(bookingId).subscribe((data)=>
    {
      console.log(data);
    })
    for(let i=0;i<this.bus.length;i++)
    {
      if(this.bus[i].busId==this.booking.busId)
      {
        this.busObj = this.bus[i];
        break;
      }
    }
    this.busObj.seatsBooked = this.busObj.seatsBooked - this.booking.seatsBooked;
    this.bookingservice.updateBus(this.busObj).subscribe((bus)=>
    {
       console.log(bus);
    })
  }
  }
}
