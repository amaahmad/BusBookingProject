package com.cg.obtrs.dao;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.exception.CustomException;

public class BookingDAOImpl implements BookingDAO 
{
	//Function that books seats as specified by the passenger 
	public String bookSeat(List<String> passengerNames,int age, long cardNumber, int cardCvv, int busId, float totalFare)throws CustomException 
	{
		BookingDTO bookingDto = new BookingDTO();
		String namesArray[] = new String[passengerNames.size()];
		Random random = new Random();
		int bookingId = random.nextInt(10000);
		BusDTO busDto = StaticDb.busList.get(busId);
		for (int i = 0; i < passengerNames.size(); i++) 
		{
			namesArray[i] = passengerNames.get(i);
		}
		bookingDto.setPassengerNames(namesArray);
		bookingDto.setSeatsBooked(passengerNames.size());
		bookingDto.setTotalFare(totalFare);
		busDto.setSeatsBooked(busDto.getSeatsBooked() + 1);
		StaticDb.bookingList.put(bookingId, bookingDto);
		return "Booking Confirmed" + " " + "Your Booking Id is : " + bookingId;
	}

	@Override
	/// Function to generate Ticket 
	public String generateTicket(int busId, int bookingId) throws CustomException 
	{
		String name = "";
		BookingDTO bookingDto = StaticDb.bookingList.get(bookingId);
		if(bookingDto==null)
		{
			return null;
		}
		else
		{
			String passengerNames[] = bookingDto.getPassengerNames();
			for (int i = 0; i < passengerNames.length; i++) 
			{
				name=name+""+passengerNames[i]+" ";
			}
			int seatsBooked = bookingDto.getSeatsBooked();
			float fare = bookingDto.getTotalFare();
			BusDTO busDto = StaticDb.busList.get(busId);
			if(busDto==null)
				return null;
			String source = busDto.getSourceStation();
			String destination = busDto.getDestinationStation();
			LocalDateTime boardingTime = busDto.getBoardingTime();
			LocalDateTime dropTime = busDto.getDropTime();

			return "Passenger Name: "+name+ "\nSeats Booked: "+ seatsBooked + "\nBooking Id: " + bookingId + "\nDeparture Station: "+source+"\nArrival station: "+destination+"\nFare: "+"Rs."+fare+"\nBoardingTime: "+boardingTime+"\nDrop Time: "+dropTime;
		}
	}

	//Function that refunds money in case of cancellation.
	public float refundMoney(int bookingId) throws CustomException
	{
		BookingDTO bookingDto = StaticDb.bookingList.get(bookingId);
		float totalFare = bookingDto.getTotalFare();
		StaticDb.bookingList.remove(bookingId);
		return totalFare;
	}

	//Function that displays the  Discounted Fare Amount for selected bus
	@Override
	public float displayFare(int age, int busId) throws CustomException 
	{
		float busFare, discountedFare = 0;
		BusDTO busDto = StaticDb.busList.get(busId);
		busFare = busDto.getFare();
		if (age < 8) {
			float discount = (0.60f * busFare);
			discountedFare = busFare - discount;
		} else {
			discountedFare = busFare;
		}
		return discountedFare;
	}

	@Override
	public String cancelBooking(int bookingId, int busId) throws CustomException 
	{    

		BusDTO busDto = StaticDb.busList.get(busId);
		if(busDto==null)
			return null;
		StaticDb.busList.get(busId).setSeatsBooked(busDto.getSeatsBooked()-1);
		BookingDTO bookingDto = StaticDb.bookingList.get(bookingId);
		if(bookingDto==null)
			return null;
		StaticDb.bookingList.get(bookingId).setSeatsBooked(bookingDto.getSeatsBooked()-1);
		return "Cancellation Successfull........\n" + "Refund has be initiated...........";
	}
	
	@Override
	public String feedback(int bookingId, String feedBack, int rating) 
	{
		BookingDTO bookingDto = StaticDb.bookingList.get(bookingId);
		bookingDto.setFeedBack(feedBack);
		bookingDto.setRating(rating);
		return "THANK YOU! FOR YOUR VALUABLE FEEDBACK";
	}
	
}
