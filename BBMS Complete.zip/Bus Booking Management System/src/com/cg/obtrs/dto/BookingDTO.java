package com.cg.obtrs.dto;

import java.util.Arrays;
public class BookingDTO 
{
	private int busId;
    private String passengerNames[];
	private Integer seatsBooked;
	private float totalFare;
	private String feedBack;
	private int rating;
	
	public BookingDTO()
	{
		super();
	}

	public BookingDTO(int busId, String[] passengerNames, Integer seatsBooked, float totalFare) 
	{
		super();
		this.busId = busId;
		this.passengerNames = passengerNames;
		this.seatsBooked = seatsBooked;
		this.totalFare = totalFare;
	}

	public int getBusId() 
	{
		return busId;
	}
	public void setBusId(int busId) 
	{
		this.busId = busId;
	}
	public String getFeedBack() 
	{
		return feedBack;
	}
	public void setFeedBack(String feedBack) 
	{
		this.feedBack = feedBack;
	}
	public int getRating() 
	{
		return rating;
	}
	public void setRating(int rating) 
	{
		this.rating = rating;
	}
	public Integer getSeatsBooked() 
	{
		return seatsBooked;
	}
	public void setSeatsBooked(Integer seatsBooked) 
	{
		this.seatsBooked = seatsBooked;
	}
	public String[] getPassengerNames() 
	{
		return passengerNames;
	}
	public void setPassengerNames(String[] passengerNames) 
	{
		this.passengerNames = passengerNames;
	}
	public float getTotalFare() 
	{
		return totalFare;
	}
	public void setTotalFare(float totalFare) 
	{
		this.totalFare = totalFare;
	}

	@Override
	public String toString() 
	{
		return "Bus Id: "+busId+"\nPassenger Name: " + Arrays.toString(passengerNames)+"\n Seats Booked: "+seatsBooked+"\ntotalFare: " + totalFare+"\n";
	}
	

}