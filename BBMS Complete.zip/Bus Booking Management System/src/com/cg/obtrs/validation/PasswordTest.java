package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class PasswordTest {
	Validation validation = new Validation();
	//Valid password
	@Test
	public void testPassword1() {
	  boolean isPasswordValid = validation.isValidPassword("Amaan123@");
	  assertTrue(isPasswordValid); 
	}
//	//Invalid password
//	@Test
//	public void testPassword2() {
//	  boolean isPasswordValid = validation.isValidPassword("Amaan123");
//	  assertTrue(isPasswordValid); 
//	}
}
