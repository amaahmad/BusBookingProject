package com.cg.obtrs.service;

import java.time.LocalDateTime;
import java.util.ArrayList;

import com.cg.obtrs.dao.AdminDAO;
import com.cg.obtrs.dao.AdminDaoImpl;
import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.exception.CustomException;

public class AdminServiceImpl implements AdminService {

	AdminDAO adminDao = new AdminDaoImpl();

	@Override
	public String adminSignUp(AdminDTO adminDto)throws CustomException {

		return adminDao.adminSignUp(adminDto);
	}

	@Override
	public String adminLogin(String userName, String password)throws CustomException {

		return adminDao.adminLoginIn(userName, password);
	}

	@Override
	public ArrayList<BusDTO> addBusOrRoute(int busId, String sourceStation, String destinationStation,
			LocalDateTime boardingTime, LocalDateTime dropTime, String busType, Integer totalSeats, Float fare)
	{

		return adminDao.addBusOrRoute(busId, sourceStation, destinationStation, boardingTime, dropTime, busType,totalSeats, fare);
	}

	@Override
	public ArrayList<BookingDTO> generateReport() throws CustomException {

		return adminDao.generateReport();
	}

	@Override
	public String cancelBooking(int busId, int bookingId) throws CustomException {

		return adminDao.cancelBooking(busId, bookingId);
	}

	@Override
	public ArrayList<BusDTO> updateSourceStation(int busId, String sourceStation) {

		return adminDao.updateSourceStation(busId, sourceStation);
	}

	@Override
	public ArrayList<BusDTO> updateDestinationStation(int busId, String destinationStation) {

		return adminDao.updateDestinationStation(busId, destinationStation);
	}

	@Override
	public ArrayList<BusDTO> updateBoardingTime(int busId, LocalDateTime boardingTime) {

		return adminDao.updateBoardingTime(busId, boardingTime);
	}

	@Override
	public ArrayList<BusDTO> updateDropTime(int busId, LocalDateTime dropTime) {

		return adminDao.updateDropTime(busId, dropTime);
	}

	@Override
	public ArrayList<BusDTO> updateBustype(int busId, String busType) {

		return adminDao.updateBustype(busId, busType);
	}

	@Override
	public ArrayList<BusDTO> updateTotalSeats(int busId, int totalSeats)throws CustomException {

		return adminDao.updateTotalSeats(busId, totalSeats);
	}

	@Override
	public ArrayList<BusDTO> updateFare(int busId, Float fare) throws CustomException{

		return adminDao.updateFare(busId, fare);
	}
	
	public boolean validatePassword(String email, String userName) throws CustomException
	{
		return adminDao.validatePassword(email,userName);
	}
	public boolean forgotPassword(String email, String userName,String newPassword) throws CustomException{
		return adminDao.forgotPassword(email,userName,newPassword);
	}
	  public void validateBusId(int busId,String function)throws CustomException
	  {
		  adminDao.validateBusId(busId,function);
	  }
}

