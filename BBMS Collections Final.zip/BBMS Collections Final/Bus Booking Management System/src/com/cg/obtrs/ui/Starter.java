package com.cg.obtrs.ui;

import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.exception.CustomException;
import com.cg.obtrs.service.AdminService;
import com.cg.obtrs.service.AdminServiceImpl;
import com.cg.obtrs.service.BookingService;
import com.cg.obtrs.service.BookingServiceImpl;
import com.cg.obtrs.service.CustomerService;
import com.cg.obtrs.service.CustomerServiceImpl;
import com.cg.obtrs.validation.Validation;

public class Starter {

	public static void main(String[] args) throws CustomException {
		Scanner input = new Scanner(System.in);
		boolean mainScreenFlag = true;
		CustomerService custService = new CustomerServiceImpl();
		BookingService bookingService = new BookingServiceImpl();
		AdminService adminService = new AdminServiceImpl();
		Validation validation = new Validation();
		System.out.println(
				"**************************************************************************************************************************************************************************");
		System.out.println(
				"                              **************************************************************************************************************");
		System.out.println(
				"                                                            *******ONLINE BUS BOOKING RESERVATION SYSTEM******");
		first: while (mainScreenFlag) {
			System.out.println("\n\n                                                                   You're:-");
			System.out.println("\n                                                                   1. ADMIN");
			System.out.println("\n                                                                   2. USER");
			System.out.println("\n                                                                   3. EXIT");
			try {
				int choice = input.nextInt();
				switch (choice) {
				case 1:
					boolean adminChoiceFlag = true;
					while (adminChoiceFlag) {
						System.out.println("\t1. Sign Up");
						System.out.println("\t2. LogIn");
						try {

							int adminChoice = input.nextInt();
							adminChoiceFlag = false;
							switch (adminChoice) {
							case 1:
								boolean userNameValidFlag = true;
								boolean emailFlag = true;
								boolean passwordFlag = true;
								boolean phoneNoFlag = true;
								boolean nameFlag = true;
								String userName = "";
								String password = "";
								String name = "";
								long phoneNo = 0;
								String email = "";
								int custId;
								while (userNameValidFlag) {
									System.out.println(
											"\tEnter Username (username can contain letters, digits, underscore and must be have min. 3 characters):");
									System.out.flush();
									userName = input.next();
									boolean checkUserName = validation.isValidUserName(userName);
									if (!checkUserName) {
										System.err.println("Username is invalid!");
										System.err.flush();
									} else
										userNameValidFlag = false;
								}
								while (passwordFlag) {
									System.out.println(
											"\tEnter Password (password must contain an uppercase, a lowercase, a digit and a special character)");
									System.out.flush();
									password = input.next();
									boolean checkPassword = validation.isValidPassword(password);
									if (!checkPassword) {
										System.err.println("Password is invalid!");
										System.err.flush();
									} else

										passwordFlag = false;
								}
								while (nameFlag) {
									System.out.println("\tEnter your Name");
									System.out.flush();
									name = input.next();
									boolean checkName = validation.isValidName(name);
									if (!checkName) {
										System.err.println("Name is invalid!");
										System.err.flush();
									} else
										nameFlag = false;
								}
								while (phoneNoFlag) {
									System.out.println("\tEnter Phone number");
									phoneNo = input.nextLong();
									if(!validation.isValidPhoneNo(phoneNo))
									
										System.err.println("PhoneNo is invalid!");
									else
										phoneNoFlag = false;
								}
								while (emailFlag) {
									System.out.println("\tEnter Email ID");
									email = input.next();
									boolean checkEmail = validation.isValidEmail(email);
									if (!checkEmail)
										System.err.println("Email is invalid!");
									else
										emailFlag = false;
								}
								Random random = new Random();
								custId = random.nextInt(1000);
								try {
									System.out.println(adminService.adminSignUp(
											new AdminDTO(name, phoneNo, email, custId, userName, password)));
								} catch (CustomException e) {
									System.out.println(e.getMessage());
								}

							case 2:
								System.out.println("\n\n\n*****************LogIn to Continue*******************");
								boolean loginScreenFlag = true;
								second: while (loginScreenFlag) {
									int loginFailureFlag = 0;
									System.out.println("\tEnter Username");
									userName = input.next();
									System.out.println("\tEnter Password");
									password = input.next();
									try {
										System.out.println(adminService.adminLogin(userName, password));
										loginScreenFlag = false;
									} catch (CustomException e) {
										loginFailureFlag = 1;
										System.out.println(e.getMessage());
									}
									if (loginFailureFlag > 0) {
										System.out.println(
												"Forgot Password? Confirm by pressing 1 or press 0 to Login again");
										int userPasswordChoice = input.nextInt();
										switch (userPasswordChoice) {
										case 0:
											loginScreenFlag = true;
											continue second;
										case 1:
											boolean flagForgotPass = true;
											while (flagForgotPass) {
												System.out.println("\tEnter your email Id");
												email = input.next();
												System.out.println("\tEnter your userName");
												userName = input.next();
												boolean flagPasswordMatch = true;

												try {
													if (adminService.validatePassword(email, userName)) {
														flagForgotPass = false;
														third: while (flagPasswordMatch) {
															System.err.flush();
															System.out.println("\tEnter New Password");
															System.out.flush();
															String newPassword = input.next();
															boolean checkPassword = validation
																	.isValidPassword(newPassword);
															if (!checkPassword) {
																System.err.println(
																		"password must contain an uppercase, a lowercase, a digit and a special character");
																System.err.flush();
																continue third;
															}
															System.out.println("\tRe-enter New Password ");
															System.out.flush();
															String renewPassword = input.next();
															if (newPassword.equals(renewPassword)) {
																flagPasswordMatch = false;
																if (adminService.forgotPassword(email, userName,
																		newPassword))
																	System.out
																			.println("Password changed successfully!");
															} else {
																flagPasswordMatch = true;

																System.err.println("Password didn't match!");

															}
														}
													} else {
														flagForgotPass = true;
														System.err.println("Email or Username is Incorrect!");
																

													}
												} catch (CustomException e) {

													e.printStackTrace();
												}

											}
											break;
										}
									}

									boolean serviceFlag = true;
									while (serviceFlag) {

										System.out.println("\n\t\t1. Add Bus or Route " + "\n\t\t 2. Generate reports "
												+ "\n\t\t 3. Update Details" + "\n\t\t 4. Cancel Booking"
												+ "\n\t\t 5. LogOut");
										int adminLoginChoice = input.nextInt();
										switch (adminLoginChoice) {
										case 1:
											int busId = 0;
											String sourceStation =null;
											String destinationStation=null;
											LocalDateTime boardingTime = null;
											LocalDateTime dropTime = null;
											String busType=null;
											int totalSeats=0;
											Float fare = 0.0f;
											boolean timeCheckFlag = true;
											boolean checkFareFlag = true;
											boolean checkSeatFlag=true;
											boolean checkStationFlag=true;
											boolean checkBusTypeFlag=true;
											System.out.println("Enter bus Id : ");
											while (timeCheckFlag) {
												busId = input.nextInt();

												try {

													adminService.validateBusId(busId, "add");
													timeCheckFlag = false;
												} catch (CustomException e) {
													System.err.println(e.getMessage());
													System.err.flush();

												}
											}
											input.nextLine();
											System.out.println("\n Enter Source Station : ");
											while(checkStationFlag) {
											 sourceStation = input.nextLine();
											 if(!validation.isValidStation(sourceStation))
												 System.err.println("Invalid Source Station! Please enter again:");
											 else checkStationFlag=false;
											}
											checkStationFlag=true;
											System.out.println("\n Enter Destination Station : ");
											while(checkStationFlag) {
											destinationStation = input.nextLine();
											if(!validation.isValidStation(destinationStation))
												System.err.println("Invalid destination Station! Please enter again:");
											else checkStationFlag=false;
											}
											System.out.println("Enter Boarding Time in yyyy mm dd hr min format:");
											timeCheckFlag = true;
											while (timeCheckFlag) {
												try {
													boardingTime = LocalDateTime.of(input.nextInt(), input.nextInt(),
															input.nextInt(), input.nextInt(), input.nextInt());
													timeCheckFlag = false;
												} catch (DateTimeException e) {
													System.err.println(
															"Invalid Date and Time. Please check and re-enter:");

												}
											}

											System.out.println("Enter Drop Time in yyyy mm dd hr min format:");
											timeCheckFlag = true;
											while (timeCheckFlag) {
												try {
													dropTime = LocalDateTime.of(input.nextInt(), input.nextInt(),
															input.nextInt(), input.nextInt(), input.nextInt());
													timeCheckFlag = false;
												} catch (DateTimeException e) {
													System.err.println(
															"Invalid Date and Time. Please check and re-enter:");

												}
											}
											input.nextLine();
											
											System.out.println("Enter Bus Type : ");
											while(checkBusTypeFlag) {
											 busType = input.nextLine();
											 if(!validation.isValidBusType(busType))
												 System.err.print("Invalid Bus type!Please enter again:");
											 else
												 checkBusTypeFlag=false;
											}
											System.out.println("Enter total number of seats : ");
											while(checkSeatFlag) {
										     totalSeats = input.nextInt();
											boolean checkSeat=validation.isValidSeats(totalSeats);
											if(!checkSeat) 
												System.err.println("Invalid number of seats! Please Enter again:");
												
											else checkSeatFlag=false;
											}
											System.out.println("Enter the fare: ");
											while (checkFareFlag) {
												fare = input.nextFloat();
												boolean checkFare = validation.isValidFare(fare);
												if (!checkFare) {
													System.err.println("Invalid Fare! Please enter again:");
												} else
													checkFareFlag = false;
											}
											System.out.println("\n" + adminService.addBusOrRoute(busId, sourceStation,
													destinationStation, boardingTime, dropTime, busType, totalSeats,
													fare));

											mainScreenFlag = false;
											break;

										case 2:
											try {
												System.out.println(adminService.generateReport());
											} catch (CustomException e) {
												System.out.println(e.getMessage());
											}
											break;

										case 3:
											boolean validateFlag = true;
											busId = 0;
											System.out.println("Enter the Bus Id:");

											while (validateFlag) {
												busId = input.nextInt();

												try {

													adminService.validateBusId(busId, "update");
													validateFlag = false;
												} catch (CustomException e) {
													System.err.println(e.getMessage());
													System.err.flush();

												}
											}
											boolean updateChoiceFlag = true;
											while (updateChoiceFlag) {
												System.out.println("\n\nSelect the field you want to update : "
														+ "\n\t\t 1. Update Source Station : "
														+ "\n\t\t 2. Update Destination Station : "
														+ "\n\t\t 3. Update Boarding Time : "
														+ "\n\t\t 4. Update Drop Time : "
														+ "\n\t\t 5. Update Bus Type :"
														+ "\n\t\t 6. Update Total Seats: "
														+ "\n\t\t 7. Update Bus fare : "
														+ "\n\t\t 8. Back to Home Page. ");

												int updateChoice = input.nextInt();

												switch (updateChoice) {
												case 1:
                                                     checkStationFlag=true;
                                                     sourceStation=null;
                                                     input.nextLine();
                                                     System.out.println("\n Enter Source Station : ");
													while(checkStationFlag) {
													 sourceStation = input.nextLine();
													 if(!validation.isValidStation(sourceStation))
														 System.err.println("Invalid Source Station! Please enter again:");
													 else checkStationFlag=false;
													}
													System.out.println("\n"
															+ adminService.updateSourceStation(busId, sourceStation));

													break;

												case 2:
													input.nextLine();
													checkStationFlag=true;
													destinationStation=null;
													System.out.println("\n Enter Destination Station : ");
													while(checkStationFlag) {
													destinationStation = input.nextLine();
													if(!validation.isValidStation(destinationStation))
														System.err.println("Invalid destination Station! Please enter again:");
													else checkStationFlag=false;
													}
													System.out.println("\n" + adminService
															.updateDestinationStation(busId, destinationStation));

													break;

												case 3:
													timeCheckFlag = true;

													System.out.println(
															"Enter the boarding Time in YYYY MM DD Hr Min format:");
													while (timeCheckFlag) {
														try {
															boardingTime = LocalDateTime.of(input.nextInt(),
																	input.nextInt(),

																	input.nextInt(), input.nextInt(), input.nextInt());
															timeCheckFlag = false;
															System.out.println("\n" + adminService
																	.updateBoardingTime(busId, boardingTime));

														} catch (DateTimeException e) {
															System.err.println("Invalid date or time! Enter again:");
														}
													}
													break;

												case 4:
													timeCheckFlag = true;
													System.out
															.println("Enter the drop time YYYY MM DD Hr Min format : ");
													while (timeCheckFlag) {
														try {
															dropTime = LocalDateTime.of(input.nextInt(),
																	input.nextInt(), input.nextInt(), input.nextInt(),
																	input.nextInt());
															timeCheckFlag = false;
															System.out.println("\n"
																	+ adminService.updateDropTime(busId, dropTime));
															input.nextLine();
															
														} catch (DateTimeException e) {
															System.err.println("Invalid Date and Time. Enter again:");
														}
													}

													break;

												case 5:
													input.nextLine();
													checkBusTypeFlag=true;
													busType=null;
													System.out.println("Enter Bus Type : ");
													while(checkBusTypeFlag) {
													 busType = input.nextLine();
													 if(!validation.isValidBusType(busType))
														 System.err.println("Invalid Bus type!Please enter again:");
													 else
														 checkBusTypeFlag=false;
													}
													System.out
															.println("\n" + adminService.updateBustype(busId, busType));
													break;

												case 6:
													
                                                    checkSeatFlag=true;
													System.out.println("\n Enter total number of seats : ");
													while(checkSeatFlag) {
														try {
													totalSeats = input.nextInt();
													System.out.println(
															"\n" + adminService.updateTotalSeats(busId, totalSeats));
													input.nextLine();
													checkSeatFlag=false;
														}catch(CustomException e)
														{
															System.err.println(e.getMessage());
														}
													}
													break;

												case 7:
													fare = 0.0f;
													checkFareFlag = true;
													System.out.println("\n Enter the fare: ");
													while (checkFareFlag) {
														try {
													    fare = input.nextFloat();
														System.out.println("\n" + adminService.updateFare(busId, fare));
														checkFareFlag=false;
														}catch(CustomException e) {
															System.err.println(e.getMessage());
														}
													}

													break;

												case 8:
													updateChoiceFlag = false;
													break;

												default:
													System.out.println("Choose a valid Option");

												}// switch_UpdateChoice
											} // while

											break;

										case 4:
											validateFlag = true;
											System.out.println("Enter the bus Id & booking Id: ");
											while (validateFlag) {

												busId = input.nextInt();
												int bookingId = input.nextInt();
												try {
													System.out.println(adminService.cancelBooking(busId, bookingId));
													validateFlag = false;
												} catch (CustomException e3) {

													System.err.println(e3.getMessage());
													System.err.flush();
												}
											}
											break;

										case 5:
											serviceFlag = false;
											loginScreenFlag = false;
											continue first;

										default:
											System.err.println("Enter a valid choice");
										}
									}
									// adminChoiceLogin_Switch
									// break;

								} // adminChoice_Switch
									// break;
							}
						} catch (InputMismatchException ie) {
							System.out.println("ENTER A VALID CHIOCE");

							input.next();
						}
					}
				case 2:
					boolean flagUser = true;
					task: while (flagUser) {
						System.out.println("\n\t1. NEW USER! SIGN UP");
						System.out.println("\t2. EXISTING USER! LOGIN");
						System.out.println("\t3. GO BACK TO MAIN MENU");
						try {
							int custChoice = input.nextInt();
							String sourceStation = "";
							String destinationStation = "";
							switch (custChoice) {
							case 1:
								boolean userNameValidFlag = true;
								boolean emailFlag = true;
								boolean passwordFlag = true;
								boolean phonenoFlag = true;
								boolean nameFlag = true;
								String userName = "";
								String password = "";
								String name = "";
								long phoneNo = 0;
								String email = "";
								while (userNameValidFlag) {
									System.out.println(
											"\n\tUSERNAME SHOULD BE 3 CHARACTERS INCLUDING LETTERS, DIGITS, UNDERSCORE");
									System.out.println("\tENTER USERNAME:");

									userName = input.next();
									boolean checkUserName = validation.isValidUserName(userName);
									if (!checkUserName)
										System.err.println("INVALID USERNAME");
									else
										userNameValidFlag = false;
								}
								while (passwordFlag) {
									System.out.println(
											"\n\tPASSWORD MUST CONTAIN A UPPERCASE, A LOWERCASE, A DIGIT AND A SPECIAL CHARACTER");
									System.out.println("\tENTER PASSWORD:");
									password = input.next();
									boolean checkPassword = validation.isValidPassword(password);
									if (!checkPassword)
										System.err.println("INVALID PASSWORD");
									else
										passwordFlag = false;
								}
								while (nameFlag) {
									String fname = "";
									String lname = "";
									boolean firstNameFlag = true;
									task6: while (firstNameFlag) {
										System.out.println("\n\tENTER FIRST NAME");
										fname = input.next();
										boolean checkFirstName = validation.isValidName(fname);
										if (!checkFirstName) {
											System.err.println("INVALID FIRST NAME");
											continue task6;
										}
										firstNameFlag = false;
									}
									boolean lastNameFlag = true;
									task7: while (lastNameFlag) {
										System.out.println("\n\tENTER LAST NAME");
										lname = input.next();
										boolean checkLastName = validation.isValidName(lname);
										if (!checkLastName) {
											System.err.println("INVALID LAST NAME");
											continue task7;
										}
										lastNameFlag = false;
									}
									name = fname + " " + lname;
									nameFlag = false;
								}
								while (phonenoFlag) {
									System.out.println("\n\tENTER PHONE NUMBER");
									phoneNo = input.nextLong();
									boolean checkPhoneNo = validation.isValidPhoneNo(phoneNo);
									if (!checkPhoneNo)
										System.err.println("INVALID PHONE NUMBER");
									else
										phonenoFlag = false;
								}
								while (emailFlag) {
									System.out.println("\n\tENTER EMAIL ID");
									email = input.next();
									boolean checkEmail = validation.isValidEmail(email);
									if (!checkEmail)
										System.err.println("INVALID EMAIL");
									else
										emailFlag = false;
								}
								Random random = new Random();
								int custId = random.nextInt(1000);
								try {
									System.out.println(custService.customerSignUp(name, phoneNo, email, custId,
											userName, password));
								} catch (CustomException e2) {
									System.out.println(e2.getMessage());
								}
								System.out.println(
										"*******************************************************************LOGIN TO CONTINUE*******************************************************************");
							case 2:
								boolean loginScreenFlag = true;
								while (loginScreenFlag) {
									int loginFailureFlag = 0;
									System.out.println("\n\tPLEASE ENTER USERNAME");
									userName = input.next();
									System.out.println("\tPLEASE ENTER PASSWORD");
									password = input.next();
									try {
										System.out.println(custService.customerLoginIn(userName, password));
										loginScreenFlag = false;
									} catch (CustomException e1) {
										loginFailureFlag = 1;
										System.out.println(e1.getMessage());
									}
									if (loginFailureFlag > 0) {
										boolean forgotPasswordChoiceFlag = true;
										while (forgotPasswordChoiceFlag) {
											System.out.println(
													"\n\tFORGOT PASSWORD?\n\t1 .TO CONTINUE\n\t2. LOGIN AGAIN\n\t3. GO BACK");
											try {
												int userPasswordChoice = input.nextInt();
												switch (userPasswordChoice) {
												case 1:
													boolean flagForgotPassword = true;
													forgotPasswordChoiceFlag = false;
													while (flagForgotPassword) {
														System.out.println("\n\tENTER YOUR EMAIL ID");
														email = input.next();
														System.out.println("\tENTER YOUR USERNAME");
														userName = input.next();
														boolean flagPasswordMatch = true;
														try {
															if (custService.validatePassword(email, userName)) {
																flagForgotPassword = false;
																while (flagPasswordMatch) {
																	System.out.println("\tENTER NEW PASSWORD");
																	String newPassword = input.next();
																	System.out.println("\tRE-ENTER NEW PASSWORD");
																	String renewPassword = input.next();
																	if (newPassword.equals(renewPassword)) {
																		flagPasswordMatch = false;
																		if (custService.forgetPassword(email, userName,
																				newPassword))
																			System.out.println(
																					"\tTHANK YOU! PASSWORD CHANGED SUCCESSFULLY");
																	} else {
																		flagPasswordMatch = true;
																		System.err.println(
																				"\tSORRY! PASSWORD DIDN'T CHANGED SUCCESSFULLY");
																	}
																}
															} else {
																System.err.println("EMAIL OR USERNAME IS INCORRECT!");
																flagForgotPassword = true;
															}
														} catch (CustomException e) {
															// TODO Auto-generated catch block
															e.printStackTrace();
														}
													}
													break;
												case 2:
													forgotPasswordChoiceFlag = false;
													loginScreenFlag = true;
													break;
												case 3:
													flagUser = true;
													loginScreenFlag = false;
													forgotPasswordChoiceFlag = false;
													continue task;
												}
											} catch (InputMismatchException ie) {
												System.err.println("INVALID CHIOCE");
												input.next();
											}
										}
									}
									if (loginScreenFlag == false) {
										boolean passChangeFlag = true;
										int bookingId;
										int busId;
										task1: while (passChangeFlag) {
											System.out.println("\n\t1. CHANGE PASSWORD");
											System.out.println("\t2. SEARCH A BUS");
											System.out.println("\t3. SORT BUS BY TIME");
											System.out.println("\t4. GENERATE TICKET");
											System.out.println("\t5. CANCEL TICKET");
											System.out.println("\t6. FEEDBACK AND RATING");
											System.out.println("\t7. LOGOUT");
											try {
												int loginChoice = input.nextInt();
												switch (loginChoice) {
												case 1:
													System.out.println("\n\tENTER YOUR EMAILID");
													String customerEmail = input.next();
													System.out.println("\tENTER CURRENT PASSWORD");
													String currentPassword = input.next();
													String newPassword = "";
													String renewPassword = "";
													boolean flagPasswordChange = true;
													while (flagPasswordChange) {
														System.out.println("\tENTER NEW PASSWORD");
														newPassword = input.next();
														System.out.println("\tRE-ENTER NEW PASSWORD");
														renewPassword = input.next();
														if (newPassword.equals(renewPassword))
															flagPasswordChange = false;
														else
															System.err.println("NEW PASSWORD DIDN'T MATCH! RE-ENTER");
													}
													try {
														boolean flag = custService.changePassword(customerEmail,
																currentPassword, newPassword);
														if (flag == true) {
															System.out.println(
																	"*******************************************************************PASSWORD CHANGED SUCCESSFULLY*******************************************************************");
															System.out.println(
																	"**************************************************************************LOGIN TO CONTINUE*******************************************************************");
															passChangeFlag = false;
															loginScreenFlag = true;
														}
													} catch (CustomException e) {
														System.out.println(e.getMessage());
													}

													break;
												case 2:
													boolean searchFlag = true;
													boolean sourceToDestinationFlag = true;
													while (sourceToDestinationFlag) {
														System.out.println("\n\tENTER SOURCE STATION");
														sourceStation = input.next();
														System.out.println("\tENTER DESTINATION STATION");
														destinationStation = input.next();
														searchFlag = true;
														while (searchFlag) {
															try {
																List<BusDTO> bus = custService.searchBus(sourceStation,
																		destinationStation);
																for (int i = 0; i < bus.size(); i++) {
																	System.out.println(bus.get(i));
																}
																System.out
																		.println("\n\t1. TO CONTINUE WITH BOOKING....");
																System.out
																		.println("\t2. CHANGE SOURCE ---> DESTINATION");
																System.out.println("\t3. GO BACK");
																try {
																	int busIdChoice = input.nextInt();
																	switch (busIdChoice) {
																	case 1:
																		boolean busFarePageFlag = true;
																		boolean busIdFlag = true;
																		while (busIdFlag) {
																			System.out
																					.println("\n\tPLEASE ENTER BUSID");
																			try {
																				busId = input.nextInt();
																				busIdFlag = false;
																				while (busFarePageFlag) {
																					System.out.println(
																							"\n\t1. DISPLAY FARE");
																					System.out.println(
																							"\t2. CHECK SEAT AVAILABILITY AND BOOK SEATS");
																					System.out.println(
																							"\t3. GO BACK TO CHOOSE BUS");
																					try {
																						int seatChoice = input
																								.nextInt();
																						switch (seatChoice) {
																						case 1:
																							boolean ageFlag = true;
																							int passengerAge = 0;
																							while (ageFlag) {
																								System.out.println(
																										"\n\tENTER YOUR AGE");
																								try {
																									passengerAge = input
																											.nextInt();
																									boolean checkAgeValid = validation
																											.isValidAge(
																													passengerAge);
																									if (checkAgeValid)
																										ageFlag = false;
																									else
																										System.out
																												.println(
																														"INVALID AGE");
																								} catch (InputMismatchException ie) {
																									System.err.println(
																											"INVALID AGE");
																									input.next();
																								}
																							}
																							try {
																								System.out.println(
																										"\tDISCOUNT FARE FOR SELECTED BUS : "
																												+ "Rs."
																												+ bookingService
																														.displayFare(
																																passengerAge,
																																busId)
																												+ "(PER PERSON)");
																								searchFlag = false;
																								sourceToDestinationFlag = false;
																							} catch (CustomException e) {
																								System.out.println(
																										e.getMessage());
																								searchFlag = true;
																								busFarePageFlag = false;
																							}
																							break;
																						case 2:
																							boolean bookSeatFlag = true;
																							System.out.println(
																									"\n\tNumber of seats available: "
																											+ custService
																													.checkSeatAvailability(
																															busId));
																							while (bookSeatFlag) {
																								System.out.println(
																										"\n\t1. BOOK SEATS");
																								System.out.println(
																										"\t2. GO BACK");
																								try {
																									searchFlag = false;
																									int bookingChoice = input
																											.nextInt();
																									switch (bookingChoice) {
																									case 1:
																										bookSeatFlag = false;
																										boolean validAgeFlag = true;
																										while (validAgeFlag) {
																											System.out
																													.println(
																															"\n\tENTER NUMBER OF SEATS TO BOOK");
																											try {
																												int noOfBookingSeats = input
																														.nextInt();
																												validAgeFlag = false;
																												if (custService
																														.checkSeatAvailability(
																																busId) < noOfBookingSeats) {
																													System.out
																															.println(
																																	"\tSORRY! THE NUMBER OF SEATS YOU HAVE SELECTED IS UNAVALIABLE");
																													break;
																												}
																												if (noOfBookingSeats >= 10) {
																													System.out
																															.println(
																																	"\tSORRY! YOU CAN'T BOOK MORE THAN 9 SEATS AT ONE TIME");
																													break;
																												}
																												float totalFare = 0;
																												int age = 0;
																												ArrayList<String> passengerNames = new ArrayList<>();

																												for (int i = 1; i <= noOfBookingSeats; i++) {
																													System.out
																															.println(
																																	"\t" + i + " "
																																			+ "PASSENGER NAME");
																													passengerNames
																															.add(input
																																	.next());
																													ageFlag = true;
																													while (ageFlag) {
																														System.out
																																.println(
																																		"\t" + i + " "
																																				+ "PASSENGER AGE");
																														try {
																															age = input
																																	.nextInt();
																															if (validation
																																	.isValidAge(
																																			age))
																																ageFlag = false;
																															else {
																																System.err
																																		.println(
																																				"INVALID AGE");
																																ageFlag = true;
																															}
																														} catch (InputMismatchException ie) {
																															System.err
																																	.println(
																																			"INVALID AGE");
																															input.next();
																														}
																													}
																													totalFare += bookingService
																															.displayFare(
																																	age,
																																	busId);
																												} // end_of_for_loop_i
																												System.out
																														.println(
																																"\tTOTAL FARE WILL BE : "
																																		+ totalFare);
																												boolean cardNumberFlag = true;
																												long cardNumber = 0;
																												while (cardNumberFlag) {
																													System.out
																															.println(
																																	"\tENTER DEBIT OR CREDIT CARD NUMBER");
																													try {
																														cardNumber = input
																																.nextLong();
																														if (validation
																																.isCardValid(
																																		cardNumber))
																															cardNumberFlag = false;
																														else {
																															System.err
																																	.println(
																																			"INVALID CARD NUMBER");
																															cardNumberFlag = true;
																														}
																													} catch (InputMismatchException ie) {
																														System.err
																																.println(
																																		"INVALID CARD NUMBER");
																														input.next();
																													}
																												}
																												boolean cvvFlag = true;
																												int cardCvv = 0;
																												while (cvvFlag) {
																													System.out
																															.println(
																																	"\tENTER CVV");
																													try {
																														cardCvv = input
																																.nextInt();
																														if (validation
																																.isValidCvv(
																																		cardCvv))
																															cvvFlag = false;
																														else {
																															System.err
																																	.println(
																																			"INVALID CVV");
																															cvvFlag = true;
																														}
																													} catch (InputMismatchException ie) {
																														System.err
																																.println(
																																		"INVALID CVV");
																														input.next();
																													}
																												}
																												System.out
																														.println(
																																bookingService
																																		.bookSeat(
																																				passengerNames,
																																				age,
																																				cardNumber,
																																				cardCvv,
																																				busId,
																																				totalFare));
																												boolean ticketChoiceFlag = true;
																												while (ticketChoiceFlag) {
																													System.out
																															.println(
																																	"\n\t1. GENERATE TICKET");
																													System.out
																															.println(
																																	"\t2. CANCEL BOOKING");
																													System.out
																															.println(
																																	"\t3. GO BACK");
																													try {
																														int ticketChoice = input
																																.nextInt();
																														ticketChoiceFlag = false;
																														switch (ticketChoice) {
																														case 1:
																															searchFlag = false;
																															boolean bookingIdFlag = true;
																															task2: while (bookingIdFlag) {
																																System.out
																																		.println(
																																				"\n\tENTER YOUR BOOKING ID");
																																try {
																																	bookingId = input
																																			.nextInt();
																																	busIdFlag = false;
																																	String ticket = bookingService
																																			.generateTicket(
																																					busId,
																																					bookingId);
																																	bookSeatFlag = false;
																																	sourceToDestinationFlag = false;
																																	if (ticket == null) {
																																		System.err
																																				.println(
																																						"NO TICKET FOUND");
																																		continue task2;
																																	}
																																	System.out
																																			.println(
																																					ticket);
																																	continue task1;
																																} catch (InputMismatchException ie) {
																																	System.err
																																			.println(
																																					"INVALID BOOKING ID");
																																	input.next();
																																}
																															}
																															break;
																														case 2:
																															bookingIdFlag = true;
																															task3: while (bookingIdFlag) {
																																System.out
																																		.println(
																																				"\n\tENTER BOOKING ID");
																																try {
																																	bookingId = input
																																			.nextInt();
																																	String cancelTicket = bookingService
																																			.cancelBooking(
																																					bookingId,
																																					busId);
																																	if (cancelTicket == null) {
																																		System.err
																																				.println(
																																						"NO TICKET FOUND");
																																		continue task3;
																																	}
																																	System.out
																																			.println(
																																					"\tAmount successfully refunded="
																																							+ "Rs."
																																							+ bookingService
																																									.refundMoney(
																																											bookingId));
																																	continue task1;
																																} catch (InputMismatchException ie) {
																																	System.err
																																			.println(
																																					"INVALID BOOKING ID");
																																	input.next();
																																}
																															}
																															break;
																														case 3:
																															bookSeatFlag = false;
																															busFarePageFlag = true;
																															break;
																														}// end_of_switch_case_ticketChoice
																													} catch (InputMismatchException ie) {
																														System.err
																																.println(
																																		"INVALID CVV");
																														input.next();
																													}
																												}
																											} catch (InputMismatchException ie) {
																												System.err
																														.println(
																																"INVALID CHIOCE");
																												input.next();
																											}
																										}
																										break;

																									case 2:
																										busFarePageFlag = true;
																										bookSeatFlag = false;
																										break;
																									}
																								} // end_of_switch_case_bookingChoice
																								catch (InputMismatchException ie) {
																									System.err.println(
																											"INVALID CHIOCE");
																									input.next();
																								}

																							} // end_of_while_bookSeatFlag
																							break;
																						case 3:
																							busFarePageFlag = false;
																							searchFlag = true;
																							break;
																						}
																					} // end_of_switch_seatChoice
																					catch (InputMismatchException ie) {
																						System.err.println(
																								"INVALID CHIOCE");
																						input.next();
																					}
																				} // end_of_switch_busFarePageFlag
																			} catch (InputMismatchException ie) {
																				System.err.println("INVALID BUS ID");
																				input.next();
																			}
																		}
																		break;
																	case 2:
																		searchFlag = false;
																		break;
																	case 3:
																		searchFlag = false;
																		sourceToDestinationFlag = false;
																		passChangeFlag = true;
																		break;
																	}
																} // end_of_switch_busIdChoice
																catch (InputMismatchException ie) {
																	System.err.println("INVALID CHIOCE");
																	input.next();
																}
															} // end_of_tryblock
															catch (CustomException e) {
																System.out.println(e.getMessage());
																sourceToDestinationFlag = true;
																break;
															} // end_of_catchblock
														} // end_of_while_searchFlag

													} // end_of_while_sourceToDestinationFlag
													break;
												case 3:
													boolean sortTimeChoiceFlag = true;
													while (sortTimeChoiceFlag) {
														System.out.println(
																"\n\tPRESS 1. TO SORT ACCORDING DEPERATURE TIME\n\tPRESS 2. TO SORT ACCORDING TO ARRIVAL TIME\n\tPRESS 3. TO GO BACK");
														try {
															int sortTimeChoice = input.nextInt();
															sortTimeChoiceFlag = false;
															switch (sortTimeChoice) {
															case 1:
																System.out.println("\tENTER SOURCE STATION");
																sourceStation = input.next();
																System.out.println("\tENTER DESTINATION STATION");
																destinationStation = input.next();
																try {
																	System.out
																			.println(custService.sortBusByDepartureTime(
																					sourceStation, destinationStation));
																} catch (CustomException e1) {
																	e1.printStackTrace();
																}
																break;
															case 2:
																System.out.println("\tENTER SOURCE STATION");
																sourceStation = input.next();
																System.out.println("\tENTER DESTINATION STATION");
																destinationStation = input.next();
																try {
																	System.out.println(custService.sortBusByArrivalTime(
																			sourceStation, destinationStation));
																} catch (CustomException e1) {
																	e1.printStackTrace();
																}
																break;
															case 3:
																passChangeFlag = true;
																break;
															default:
																System.out.println("INVALID INPUT");
															}
														} catch (InputMismatchException ie) {
															System.err.println("INVALID CHIOCE");
															input.next();
														}
													}
													break;
												case 4:
													searchFlag = false;
													boolean busIdFlag = true;
													task4: while (busIdFlag) {
														System.out.println("\n\tENTER BUS ID");
														try {
															busId = input.nextInt();
															busIdFlag = false;
															boolean bookingIdFlag = true;
															while (bookingIdFlag) {
																System.out.println("\tENTER YOUR BOOKING ID");
																try {
																	bookingId = input.nextInt();
																	bookingIdFlag = false;
																	try {
																		String ticket = bookingService
																				.generateTicket(busId, bookingId);
																		if (ticket == null) {
																			System.err.println("NO TICKET FOUND");
																			busIdFlag = true;
																			bookingIdFlag = true;
																			continue task4;
																		}
																		System.out.println(ticket);
																	} catch (CustomException e) {
																		// TODO Auto-generated catch block
																		e.printStackTrace();
																	}
																	sourceToDestinationFlag = false;
																} catch (InputMismatchException ie) {
																	System.err.println("INVALID BOOKING ID");
																	input.next();
																}
															}
														} catch (InputMismatchException ie) {
															System.err.println("INVALID BUS ID");
															input.next();
														}
													}
													break;
												case 5:
													busIdFlag = true;
													task4: while (busIdFlag) {
														System.out.println("\n\tENTER BUS ID");
														try {
															busId = input.nextInt();
															busIdFlag = false;
															boolean bookingIdFlag = true;
															while (bookingIdFlag) {
																System.out.println("\tENTER YOUR BOOKING ID");
																try {
																	bookingId = input.nextInt();
																	bookingIdFlag = false;

																	try {
																		String cancelTicket = bookingService
																				.cancelBooking(bookingId, busId);
																		if (cancelTicket == null) {
																			System.err.println("NO TICKET FOUND");
																			busIdFlag = true;
																			bookingIdFlag = true;
																			continue task4;
																		} else
																			System.out.println(
																					"\tAmount successfully refunded="
																							+ "Rs."
																							+ bookingService
																									.refundMoney(
																											bookingId));
																	} catch (CustomException e) {
																		// TODO Auto-generated catch block
																		e.printStackTrace();
																	}
																} catch (InputMismatchException ie) {
																	System.err.println("INVALID BOOKING ID");
																	input.next();
																}
															}
														} catch (InputMismatchException ie) {
															System.err.println("INVALID BUS ID");
															input.next();
														}
													}
													break;
												case 6:
													boolean bookingIdFlag = true;
													while (bookingIdFlag) {
														System.out.println("\n\tENTER BOOKING ID");
														try {
															bookingId = input.nextInt();
															System.out.println(
																	"\tPLEASE! ENTER FEEDBACK AS POOR AVERAGE GOOD EXCELLENT");
															String feedBack = input.next();
															boolean ratingFlag = true;
															while (ratingFlag) {
																System.out.println("\tPLEASE! ENTER RATING OUT OF 5");
																ratingFlag = false;
																try {
																	int rating = input.nextInt();

																	System.out.println(bookingService
																			.feedback(bookingId, feedBack, rating));
																} catch (InputMismatchException ie) {
																	System.err.println("INVALID RATING");
																	input.next();
																}
															}
														} catch (InputMismatchException ie) {
															System.err.println("INVALID BOOKING ID");
															input.next();
														}
													}
													break;
												case 7:
													passChangeFlag = false;
													loginScreenFlag = false;
													mainScreenFlag = true;
													break;
												}
											} catch (InputMismatchException ie) {
												System.err.println("INVALID CHIOCE");
												input.next();
											} // end_of_switch_loginChoice
										} // end_of_while_passChangeFlag
									}
								}
								break;
							case 3:
								flagUser = false;
								mainScreenFlag = true;
								break;
							}
						} catch (InputMismatchException ie) {
							System.err.println("INVALID CHIOCE");
							input.next();
						}
					}
					break;
				case 3:
					input.close();
					System.out.println(
							"                                                            *********EXITING ONLINE BUS BOOKING SYSTEM*********");
					System.out.println(
							"                              **************************************************************************************************************");
					System.out.println(
							"**************************************************************************************************************************************************************************");

					System.exit(0);
				}// Choice_Switch
			} catch (InputMismatchException ie) {
				System.out.println("\t\t\t\t\t\t\tINVALID CHIOCE! CHOOSE AGAIN:");
				input.next();
			}

		} // Main_While
	}
}
