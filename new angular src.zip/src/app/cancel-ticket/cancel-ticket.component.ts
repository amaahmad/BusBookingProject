import { Component, OnInit } from '@angular/core';
import { Booking } from '../Booking';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { BusService } from '../bus.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {
  flag1:any;
  constructor(private bookingSer:BookingService,private router:Router) { }
  cancelticket = new FormGroup({
    bookingId: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.bookingSer.getBooking();
    }
  cancelTicket()
  {
    if(this.cancelticket.valid)
    {
    let bookingId=this.cancelticket.get('bookingId').value;
    let k=0;
    for(let i=0;i<this.bookingSer.bookingDb.length;i++) 
    {
      if (this.bookingSer.bookingDb[i].id==bookingId)
      {     
        this.bookingSer.deleteBooking(bookingId).subscribe(data=>{console.log(data)});
        this.bookingSer.flag=true;
      }     
    }
    if (this.bookingSer.flag) 
    {
      this.flag1=true;
    }
  }
  }

}
