import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {UserComponent} from './user/user.component'
import { HomeComponent } from './home/home.component';
import { BusbookingComponent } from './busbooking/busbooking.component';
import { GenerateTicketComponent } from './generate-ticket/generate-ticket.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ChangeAgeComponent } from './change-age/change-age.component';
import { ChangeNameComponent } from './change-name/change-name.component';
import { ChangePhoneNumberComponent } from './change-phone-number/change-phone-number.component';
import { FeedbackRatingComponent } from './feedback-rating/feedback-rating.component';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FirstPageComponent } from './first-page/first-page.component';
import { AboutComponent } from './about/about.component';
import { SignupComponent } from './signup/signup.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  {path:'user',component:UserComponent},
  {path:'home',component:HomeComponent},
  {path:'busbooking',component:BusbookingComponent},
  {path:'generate-ticket',component:GenerateTicketComponent},
  {path:'cancel-ticket',component:CancelTicketComponent},
  {path:'change-password',component:ChangePasswordComponent},
  {path:'change-age',component:ChangeAgeComponent},
  {path:'change-name',component:ChangeNameComponent},
  {path:'change-phone-number',component:ChangePhoneNumberComponent},
  {path:'feedback-rating',component:FeedbackRatingComponent},
  {path:'app',component:AppComponent},
  {path:'admin',component:AdminComponent},
  {path:'forgot-password',component:ForgotPasswordComponent},
  {path:'first-page',component:FirstPageComponent},
  {path:'about',component:AboutComponent},
  {path:'signup', component:SignupComponent},
  {path:'profile', component:ProfileComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
