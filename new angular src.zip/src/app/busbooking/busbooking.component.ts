import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Booking } from '../Booking';
import { BusService } from '../bus.service';

@Component({
  selector: 'app-busbooking',
  templateUrl: './busbooking.component.html',
  styleUrls: ['./busbooking.component.css']
})
export class BusbookingComponent implements OnInit 
{
 id:any;
 booking:Booking[]=[];
  constructor(private bookingSer:BookingService,private router:Router,private busSer:BusService) { }
  bookingDetail = new FormGroup({
    busId: new FormControl(''),
    seatBooked: new FormControl(''),
    passengerName1: new FormControl(''),
    passengerName2: new FormControl(''),
    passengerName3: new FormControl(''),
    passengerName4: new FormControl(''),
    passengerName5: new FormControl(''),
    passengerEmail: new FormControl('')
  });
  ngOnInit(): void 
  {
    this.bookingSer.getBooking();
    this.busSer.getBus();
  }
  busBook()
  {
  if(this.bookingDetail.valid)
  {
    let busId=this.bookingDetail.get('busId').value;
    let seatBooked=this.bookingDetail.get('seatBooked').value;
    let passengerName1=this.bookingDetail.get('passengerName1').value;
    let passengerName2=this.bookingDetail.get('passengerName2').value;
    let passengerName3=this.bookingDetail.get('passengerName3').value;
    let passengerName4=this.bookingDetail.get('passengerName4').value;
    let passengerName5=this.bookingDetail.get('passengerName5').value;
    let passengerEmail=this.bookingDetail.get('passengerEmail').value;
    let id=this.bookingSer.bookingDb[0].id;
    for(let i=1;i<this.bookingSer.bookingDb.length;i++)
    {
      if(id<this.bookingSer.bookingDb[i].id)
      {
        id=this.bookingSer.bookingDb[i].id;
      }
    }
    id++;
    this.id=id;
    let passengerName:any[]=[passengerName1,passengerName2,passengerName3,passengerName4,passengerName5];
    let passengerNames:any[]=[];
    for(let i=0;i<seatBooked;i++)
    {
      passengerNames[i]=passengerName[i]
    }
    let totalFare;
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
      if(this.busSer.busDb[i].id==busId)
      {
        totalFare=this.busSer.busDb[i].fare*seatBooked;
      }
    }
    let feedBack="null";
    let rating=0;
    let tempBooking:Booking=new Booking(id, busId, passengerNames, seatBooked, passengerEmail,totalFare,feedBack,rating);
    this.bookingSer.addBooking(tempBooking).subscribe(data=>{console.log(data)}); 
    this.booking[0]=tempBooking;
  }
}
}
