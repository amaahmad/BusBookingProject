import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, FormGroup, ReactiveFormsModule} from '@angular/forms';
import { BusService } from './bus.service';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { GenerateTicketComponent } from './generate-ticket/generate-ticket.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { BusbookingComponent } from './busbooking/busbooking.component';
import { ChangeAgeComponent } from './change-age/change-age.component';
import { ChangeNameComponent } from './change-name/change-name.component';
import { ChangePhoneNumberComponent } from './change-phone-number/change-phone-number.component';
import { FeedbackRatingComponent } from './feedback-rating/feedback-rating.component';
import { AdminComponent } from './admin/admin.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FirstPageComponent } from './first-page/first-page.component';
import { SignupComponent } from './signup/signup.component';
import { ProfileComponent } from './profile/profile.component';
import { CustomerService } from './customer.service';
import { BookingService } from './booking.service';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    HomeComponent,
    BusbookingComponent,
    GenerateTicketComponent,
    CancelTicketComponent,
    ChangePasswordComponent,
    BusbookingComponent,
    ChangeAgeComponent,
    ChangeNameComponent,
    ChangePhoneNumberComponent,
    FeedbackRatingComponent,
    AdminComponent,
    ForgotPasswordComponent,
    FirstPageComponent,
    SignupComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule
  ],
  providers: [BusService,CustomerService,BookingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
