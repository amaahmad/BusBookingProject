package com.cg.obtrs.ui;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.exception.CustomException;
import com.cg.obtrs.service.AdminService;
import com.cg.obtrs.service.AdminServiceImpl;
import com.cg.obtrs.service.BookingService;
import com.cg.obtrs.service.BookingServiceImpl;
import com.cg.obtrs.service.CustomerService;
import com.cg.obtrs.service.CustomerServiceImpl;
import com.cg.obtrs.validation.Validation;

public class Starter {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		boolean mainScreenFlag = true;
		CustomerService custService = new CustomerServiceImpl();
		BookingService bookingService = new BookingServiceImpl();
		AdminService adminService = new AdminServiceImpl();
		Validation validation = new Validation();
		System.out.println("**************************************************************************************************************************************************************************");
		System.out.println("                              **************************************************************************************************************");
		System.out.println("                                                            *******ONLINE BUS BOOKING RESERVATION SYSTEM******");
		while (mainScreenFlag) 
		{
			System.out.println("\n\n                                                                   You're:-");
			System.out.println("\n                                                                   1. ADMIN");
			System.out.println("\n                                                                   2. USER");
			System.out.println("\n                                                                   3. EXIT");
			int choice = input.nextInt();
			switch (choice) 
			{
			case 1: // while(temp>0)
				System.out.println("1. Sign Up");
				System.out.println("2. LogIn");
				int adminChoice = input.nextInt();
				switch (adminChoice) 
				{
				case 1:
					System.out.println("Enter Username");
					String userName = input.next();
					System.out.println("Enter Password");
					String password = input.next();
					System.out.println("Enter your Name");
					String name = input.next();
					System.out.println("Enter Phone number");
					long phoneNo = input.nextLong();
					System.out.println("Enter Email ID");
					String email = input.next();
					Random random = new Random();
					int custId = random.nextInt(1000);
					System.out.println(adminService.adminSignUp(new AdminDTO(name, phoneNo, email, custId, userName, password)));
					break;

				case 2:
					System.out.println("\n\n------FOR LOGIN-------\n");
					System.out.println("Enter Username");
					userName = input.next();
					System.out.println("Enter Password");
					password = input.next();
					System.out.println(adminService.adminLogin(userName, password));
					boolean flag = true;
					while (flag) 
					{
						System.out.println("1. Add Bus or Route " + "\n 2. Generate reports " + "\n 3. Update Details"+ "\n 4. Cancel Booking" + "\n 5. Exit");
						int adminLoginChoice = input.nextInt();
						switch (adminLoginChoice) 
						{
						case 1:
							System.out.println("Enter bus Id : ");
							int busId = input.nextInt();
							System.out.println("\n Enter Source Station : ");
							String sourceStation = input.next();
							System.out.println("\n Enter Destination Station : ");
							String destinationStation = input.next();
							System.out.println("Enter Boarding Time in yyyy-mm-dd-hr-min");
							LocalDateTime boardingTime = LocalDateTime.of(input.nextInt(), input.nextInt(),input.nextInt(), input.nextInt(), input.nextInt());
							System.out.println("Enter Drop Time in yyyy-mm-dd-hr-min");
							LocalDateTime dropTime = LocalDateTime.of(input.nextInt(), input.nextInt(), input.nextInt(),input.nextInt(), input.nextInt());
							System.out.println("\n Enter Bus Type : ");
							String busType = input.next();
							System.out.println("\n Enter total number of seats : ");
							int totalSeats = input.nextInt();
							System.out.println("\n Enter the fare: ");
							Float fare = input.nextFloat();
							System.out.println(adminService.addBusOrRoute(busId, sourceStation, destinationStation,boardingTime, dropTime, busType, totalSeats, fare));
							mainScreenFlag = false;
							break;

						case 2:
							System.out.println(adminService.generateReport());
							break;

						case 3:

							System.out.println("Enter the Bus Id:");
							busId = input.nextInt();
							boolean updateChoiceFlag = true;
							while (updateChoiceFlag) 
							{
								System.out.println("Select the field you want to update : "
										+ "\n 1. Update Source Station : " + "\n 2. Update Destination Station : "
										+ "\n 3. Update Boarding Time : " + "\n 4. Update Drop Time : "
										+ "\n 5. Update Bus Type :" + "\n 6. Update Total Seats: "
										+ "\n 7. Update Bus fare : " + "\n 8. Exit. ");
								int updateChoice = input.nextInt();
								switch (updateChoice) 
								{
								case 1:
									System.out.println("\n Enter Source Station : ");
									sourceStation = input.next();
									adminService.updateSourceStation(busId, sourceStation);
									break;

								case 2:
									System.out.println("\n Enter Destination Station : ");
									destinationStation = input.next();
									adminService.updateSourceStation(busId, destinationStation);
									break;

								case 3:
									System.out.println("Enter the boarding Time");
									// LocalDateTime boardingTime = input.
									break;

								case 4:
									System.out.println("Enter the drop time : ");
									break;

								case 5:
									System.out.println("Enter the bus Type:  ");
									busType = input.next();
									adminService.updateBustype(busId, busType);
									break;

								case 6:
									System.out.println("\n Enter total number of seats : ");
									totalSeats = input.nextInt();
									adminService.updateTotalSeats(busId, totalSeats);
									break;

								case 7:
									System.out.println("\n Enter the fare: ");
									fare = input.nextFloat();
									adminService.updateFare(busId, fare);
									break;

								case 8:
									updateChoiceFlag = false;
									break;

								default:
									System.out.println("Choose a valid Option");

								}// switch_UpdateChoice
							} // while

							break;

						case 4:

							System.out.println("Enter the bus Id : ");
							busId = input.nextInt();
							System.out.println("\n Enter the booking Id : ");
							int bookingId = input.nextInt();
							try 
							{
								System.out.println(adminService.cancelBooking(busId, bookingId));
							} catch (CustomException e3) {
								// TODO Auto-generated catch block
								e3.printStackTrace();
							}

						case 5:
							flag = false;
							break;
						}
					}
					// adminChoiceLogin_Switch
					break;

				}// adminChoice_Switch
				break;

			case 2: 
				boolean flagUser=true;
				while(flagUser)
				{
					System.out.println("\n\t1. NEW USER! SIGN UP");
					System.out.println("\t2. EXISTING USER! LOGIN");
					System.out.println("\t3. GO BACK TO MAIN MENU");
					int custChoice = input.nextInt();
					String sourceStation ="";
					String destinationStation="";
					switch (custChoice) 
					{
					case 1:
						boolean userNameValidFlag = true;
						boolean emailFlag = true;
						boolean passwordFlag = true;
						boolean phonenoFlag = true;
						boolean nameFlag = true;
						boolean ageValidFlag = true;
						int age =0;
						String userName = "";
						String password = "";
						String name = "";
						long phoneNo = 0;
						String email = "";
						while (userNameValidFlag) 
						{
							System.out.println("\n\tUSERNAME SHOULD BE 3 CHARACTERS INCLUDING LETTERS, DIGITS, UNDERSCORE");
							System.out.println("\tENTER USERNAME:");

							userName = input.next();
							boolean checkUserName = validation.isValidUserName(userName);
							if (!checkUserName)
								System.err.println("\n\tUSERNAME IS INVALID!");
							else
								userNameValidFlag = false;
						}
						while (passwordFlag) 
						{
							System.out.println("\n\tPASSWORD MUST CONTAIN A UPPERCASE, A LOWERCASE, A DIGIT AND A SPECIAL CHARACTER");
							System.out.println("\tENTER PASSWORD:");
							password = input.next();
							boolean checkPassword = validation.isValidPassword(password);
							if (!checkPassword)
								System.err.println("\n\tPASSWORD IS INVALID!");
							else
								passwordFlag = false;
						}
						while (nameFlag) 
						{
							System.out.println("\n\tENTER NAME");
							name = input.next();
							//						input.skip("\n\r");
							boolean checkName = validation.isValidName(name);
							if (!checkName)
								System.err.println("\n\tNAME IS INVALID!");
							else
								nameFlag = false;
						}
						while (phonenoFlag) 
						{
							System.out.println("\n\tENTER PHONE NUMBER");
							phoneNo = input.nextLong();
							boolean checkPhoneNo = validation.isValidPhoneNo(phoneNo);
							if (!checkPhoneNo)
								System.err.println("\n\tPHONE NUMBER IS INVALID!");
							else
								phonenoFlag = false;
						}
						while (emailFlag) 
						{
							System.out.println("\n\tENTER EMAIL ID");
							email = input.next();
							boolean checkEmail = validation.isValidEmail(email);
							if (!checkEmail)
								System.err.println("\n\tEMAIL IS INVALID!");
							else
								emailFlag = false;
						}
						while (ageValidFlag) 
						{
							System.out.println("\n\tENTER YOUR AGE");
							age = input.nextInt();
							boolean checkAge = validation.isValidAge(age);
							if (!checkAge)
								System.err.println("\n\tAGE IS INVALID!");
							else
								ageValidFlag = false;
						}
						
						Random random = new Random();
						 int custId = random.nextInt(1000);
						try 
						{
							System.out.println(custService.customerSignUp(name, phoneNo, email, custId, userName, password, age));
						} 
						catch (CustomException e2) 
						{
							System.out.println(e2.getMessage());
						}
						System.out.println("*******************************************************************LOGIN TO CONTINUE*******************************************************************");
					case 2:
						boolean loginScreenFlag = true;
						while (loginScreenFlag) 
						{
							int loginFailureFlag = 0;
							System.out.println("\n\tPLEASE ENTER USERNAME");
							userName = input.next();
							System.out.println("\n\tPLEASE ENTER PASSWORD");
							password = input.next();
							try 
							{
								System.out.println(custService.customerLoginIn(userName, password));
								loginScreenFlag = false;
							}
							catch (CustomException e1) 
							{
								loginFailureFlag = 1;
								System.out.println(e1.getMessage());
							}
							if (loginFailureFlag > 0) 
							{
								System.out.println("\n\tFORGOT PASSWORD?\n\t1 .TO CONTINUE\n\t2. LOGIN AGAIN\n\t3. GO BACK");
								int userPasswordChoice = input.nextInt();
								switch (userPasswordChoice) 
								{
								case 1:
									boolean flagForgotPassword=true;
									while(flagForgotPassword)
									{
										System.out.println("\n\tENTER YOUR EMAIL ID");
										email = input.next();
										System.out.println("\n\tENTER YOUR USERNAME");
										userName = input.next();
										boolean flagPasswordMatch = true;
										try 
										{
											if (custService.validatePassword(email, userName)) 
											{
												flagForgotPassword=false;
												while (flagPasswordMatch) 
												{
													System.out.println("\n\tENTER NEW PASSWORD");
													String newPassword = input.next();
													System.out.println("\n\tRE-ENTER NEW PASSWORD");
													String renewPassword = input.next();
													if (newPassword.equals(renewPassword)) 
													{
														flagPasswordMatch = false;
														if (custService.forgetPassword(email, userName, newPassword))
															System.out.println("\n\tTHANK YOU! PASSWORD CHANGED SUCCESSFULLY");
													} 
													else 
													{
														flagPasswordMatch = true;
														System.out.println("\n\tSORRY! PASSWORD DIDN'T CHANGED SUCCESSFULLY");
													}
												}
											}
											else
											{
												System.out.println("EMAIL OR USERNAME IS INCORRECT!");
												flagForgotPassword=true;
											}
										} 
										catch (CustomException e) 
										{
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
									break;
								case 2:
									loginScreenFlag = true;
									break;
								case 3:
									flagUser=true;
									loginScreenFlag=false;
									continue;
								}
							}
							if (loginScreenFlag == false) 
							{
								boolean passChangeFlag = true;
								int bookingId;
								int busId;
								while (passChangeFlag) 
								{
									System.out.println("\n\t1. CHANGE PASSWORD");
									System.out.println("\n\t2. SEARCH A BUS");
									System.out.println("\n\t3. SORT BUS BY TIME");
									System.out.println("\n\t4. GENERATE TICKET");
									System.out.println("\n\t5. CANCEL TICKET");
									System.out.println("\n\t6. FEEDBACK AND RATING");
									System.out.println("\n\t7. LOGOUT");
									int loginChoice = input.nextInt();
									switch (loginChoice) 
									{
									case 1:
										System.out.println("\n\tENTER YOUR EMAILID");
										String customerEmail = input.next();
										System.out.println("\n\tENTER CURRENT PASSWORD");
										String currentPassword = input.next();
										String newPassword="";
										String renewPassword="";
										boolean flagPasswordChange=true;
										while(flagPasswordChange)
										{
											System.out.println("\n\tENTER NEW PASSWORD");
											newPassword = input.next();
											System.out.println("\n\tRE-ENTER NEW PASSWORD");
											renewPassword=input.next();
											if(newPassword.equals(renewPassword))
												flagPasswordChange=false;
											else
												System.out.println("NEW PASWORD DIDN'T MATCH! RE-ENTER");
										}
										try 
										{
											boolean flag = custService.changePassword(customerEmail, currentPassword,newPassword);
											if (flag == true) 
											{
												System.out.println("*******************************************************************PASSWORD CHANGED SUCCESSFULLY*******************************************************************");
												System.out.println("**************************************************************************LOGIN TO CONTINUE*******************************************************************");
												passChangeFlag = false;
												loginScreenFlag = true;
											}
										} 
										catch (CustomException e) 
										{
											System.out.println(e.getMessage());
										}

										break;
									case 2:
										boolean searchFlag = true;
										boolean sourceToDestinationFlag = true;
										while (sourceToDestinationFlag) 
										{
											System.out.println("\n\tENTER SOURCE STATION");
											sourceStation = input.next();
											System.out.println("\n\tENTER DESTINATION STATION");
											destinationStation = input.next();
											searchFlag = true;
											while(searchFlag) 
											{
												try 
												{
													List<BusDTO> bus=custService.searchBus(sourceStation, destinationStation);
													for(int i=0;i<bus.size();i++)
													{
														System.out.println(bus.get(i));
													}
													System.out.println("\n\t1. TO CONTINUE WITH BOOKING....");
													System.out.println("\n\t2. CHANGE SOURCE ---> DESTINATION");
													System.out.println("\n\t3. GO BACK");
													int busIdChoice = input.nextInt();
													switch (busIdChoice) 
													{
													case 1:
														boolean busFarePageFlag = true;
														System.out.println("\n\tPLEASE ENTER BUSID");
														busId = input.nextInt();
														while (busFarePageFlag) 
														{
															System.out.println("\n\t1. DISPLAY FARE");
															System.out.println("\n\t2. CHECK SEAT AVAILABILITY AND BOOK SEATS");
															System.out.println("\n\t3. GO BACK TO CHOOSE BUS");
															int seatChoice = input.nextInt();
															switch (seatChoice) 
															{
															case 1:
																boolean ageFlag = true;
																int passengerAge = 0;
																while (ageFlag) 
																{
																	System.out.println("\n\tENTER YOUR AGE");
																	passengerAge = input.nextInt();
																	boolean checkAgeValid = validation.isValidAge(passengerAge);
																	if (checkAgeValid)
																		ageFlag = false;
																	else
																		System.out.println("\n\tInvalid Age!");
																}
																try 
																{
																	System.out.println("\n\tDISCOUNT FARE FOR SELECTED BUS : "+"Rs."+bookingService.displayFare(passengerAge,busId)+"(PER PERSON)");
																	searchFlag = false;
																	sourceToDestinationFlag = false;
																} 
																catch (CustomException e) 
																{
																	System.out.println(e.getMessage());
																	searchFlag = true;
																	busFarePageFlag = false;
																}
																break;
															case 2:
																boolean bookSeatFlag = true;
																System.out.println("\n\tNumber of seats Available: "+ custService.checkSeatAvailability(busId));
																while (bookSeatFlag) 
																{
																	System.out.println("\n\t1. BOOK SEATS");
																	System.out.println("\n\t2. GO BACK");
																	searchFlag = false;
																	int bookingChoice = input.nextInt();
																	switch (bookingChoice)
																	{
																	case 1:
																		bookSeatFlag = false;
																		System.out.println("\n\tENTER NUMBER OF SEATS TO BOOK");
																		int noOfBookingSeats = input.nextInt();
																		if(custService.checkSeatAvailability(busId)<noOfBookingSeats)
																		{
																			System.out.println("\n\tSORRY! THE NUMBER OF SEATS YOU HAVE SELECTED IS UNAVALIABLE");
																			break;
																		}
																		if(noOfBookingSeats>=10)
																		{
																			System.out.println("\n\tSORRY! YOU CAN'T BOOK MORE THAN 9 SEATS AT ONE TIME");
																			break;
																		}
																		float totalFare = 0;
																	     age =0;
																		ArrayList<String> passengerNames = new ArrayList<>();

																		for (int i = 1; i <= noOfBookingSeats; i++) 
																		{
																			System.out.println("\n\t"+i+" "+ "PASSENGER NAME");
																			passengerNames.add(input.next());
																			ageFlag = true;
																			while(ageFlag)
																			{
																				System.out.println("\n\t"+i+" "+ "PASSENGER AGE");
																				age = input.nextInt();
																				if(validation.isValidAge(age))
																					ageFlag = false;
																				else
																				{
																					System.out.println("\n\tINVALID AGE!");
																					ageFlag = true; 
																				}
																			}
																			totalFare += bookingService.displayFare(age,busId);
																		} // end_of_for_loop_i
																		System.out.println("\n\tTOTAL FARE WILL BE : " + totalFare);
																		boolean cardNumberFlag = true;
																		long cardNumber = 0;
																		while(cardNumberFlag)
																		{
																			System.out.println("\n\tENTER DEBIT OR CREDIT CARD NUMBER");

																			cardNumber = input.nextLong();
																			if(validation.isCardValid(cardNumber))
																				cardNumberFlag = false;
																			else
																			{
																				System.out.println("\n\tINVALID CARD NUMBER!");
																				cardNumberFlag = true;
																			}
																		}
																		boolean cvvFlag = true;
																		int cardCvv= 0;
																		while(cvvFlag)
																		{
																			System.out.println("\n\tENTER CVV");

																			cardCvv = input.nextInt();
																			if(validation.isValidCvv(cardCvv))
																				cvvFlag = false;
																			else
																			{
																				System.out.println("\n\tINVALID CVV!");
																				cvvFlag = true;
																			}

																		}
																		System.out.println(bookingService.bookSeat(passengerNames,age,cardNumber,cardCvv,busId,totalFare));
																		System.out.println("\n\t1. GENERATE TICKET");
																		System.out.println("\n\t2. CANCEL BOOKING");
																		System.out.println("\n\t3. GO BACK");
																		int ticketChoice = input.nextInt();
																		switch (ticketChoice) 
																		{
																		case 1:
																			searchFlag = false;
																			System.out.println("\n\tENTER YOUR BOOKING ID");
																			bookingId = input.nextInt();
																			System.out.println(bookingService.generateTicket(busId, bookingId));
																			bookSeatFlag = false;
																			sourceToDestinationFlag = false;
																			break;
																		case 2:
																			System.out.println("\n\tENTER BOOKING ID");
																			bookingId = input.nextInt();
																			System.out.println(bookingService.cancelBooking(bookingId, busId));
																			System.out.println("\n\tAmount successfully refunded=" + "Rs."+ bookingService.refundMoney(bookingId));
																			break;
																		case 3:
																			bookSeatFlag=false;
																			busFarePageFlag=true;
																			break;
																		}// end_of_switch_case_ticketChoice'
																		break;
																	case 2:
																		busFarePageFlag = true;
																		bookSeatFlag = false;
																		break;
																	}// end_of_switch_case_bookingChoice
																} // end_of_while_bookSeatFlag
																break;
															case 3:
																busFarePageFlag = false;
																searchFlag = true;
																break;
															}// end_of_switch_seatChoice
														} // end_of_switch_busFarePageFlag
														break;
													case 2:
														searchFlag = false;
														break;
													case 3:
														searchFlag=false;
														sourceToDestinationFlag=false;
														passChangeFlag=true;
														break;
													}// end_of_switch_busIdChoice
												} // end_of_tryblock
												catch (CustomException e) 
												{
													System.out.println(e.getMessage());
													sourceToDestinationFlag = true;
													break;
												} // end_of_catchblock
											} // end_of_while_searchFlag

										} // end_of_while_sourceToDestinationFlag
										break;
									case 3:
										System.out.println("\n\tPRESS 1. TO SORT ACCORDING DEPERATURE TIME\n\tPRESS 2. TO SORT ACCORDING TO ARRIVAL TIME\n\tPRESS 3. TO GO BACK");
										int sortTimeChoice=input.nextInt();
										switch(sortTimeChoice)
										{
										case 1:
											System.out.println("ENTER SOURCE STATION");
											sourceStation=input.next();
											System.out.println("ENTER DESTINATION STATION");
											destinationStation=input.next();
											try 
											{
												System.out.println(custService.sortBusByDepartureTime(sourceStation,destinationStation));
											} 
											catch (CustomException e1) 
											{
												e1.printStackTrace();
											}
											break;
										case 2:
											System.out.println("ENTER SOURCE STATION");
											sourceStation=input.next();
											System.out.println("ENTER DESTINATION STATION");
											destinationStation=input.next();
											try 
											{
												System.out.println(custService.sortBusByArrivalTime(sourceStation,destinationStation));
											} 
											catch (CustomException e1) 
											{
												e1.printStackTrace();
											}
											break;
										case 3:
											passChangeFlag=true;
											break;
										default:
											System.out.println("\n\tINVALID INPUT");
										}
										break;
									case 4:
										searchFlag = false;
										System.out.println("\n\tENTER BUS ID");
										busId=input.nextInt();
										System.out.println("\n\tENTER YOUR BOOKING ID");
										bookingId = input.nextInt();
										try 
										{
											System.out.println(bookingService.generateTicket(busId, bookingId));
										} 
										catch (CustomException e) 
										{
											// TODO Auto-generated catch block
											System.err.println(e.getMessage());
										}
										sourceToDestinationFlag = false;
										break;
									case 5:
										System.out.println("\n\tENTER BUS ID");
										busId=input.nextInt();
										System.out.println("\n\tENTER BOOKING ID");
										bookingId = input.nextInt();
										try 
										{
											System.out.println(bookingService.cancelBooking(bookingId, busId));
											System.out.println("\n\tAmount successfully refunded=" + "Rs."+ bookingService.refundMoney(bookingId));
										} 
										catch (CustomException e) 
										{
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
											
										break;
									case 6:
										System.out.println("PLEASE ENTER YOUR EMAIL ID");
										email = input.next();
										System.out.println("ENTER BOOKING ID");
										bookingId=input.nextInt();
										System.out.println("PLEASE! ENTER FEEDBACK AS POOR AVERAGE GOOD EXCELLENT");
										String feedBack=input.next();
										System.out.println("PLEASE! ENTER RATING OUT OF 5");
										int rating=input.nextInt();
										try {
											System.out.println(custService.customerFeedback(email, feedBack, rating));
										} catch (CustomException e) {
											// TODO Auto-generated catch block
											 System.err.println(e.getMessage());
										}
										break;
									case 7:
										passChangeFlag = false;
										loginScreenFlag = false;
										mainScreenFlag = true;
										break;
									}// end_of_switch_loginChoice
								} // end_of_while_passChangeFlag
							}
						}
						break;
					case 3:
						flagUser=false;
						mainScreenFlag=true;
						break;
					}
				}
				break;
			case 3:
				input.close();
				System.out.println("                                                            *********EXITING ONLINE BUS BOOKING SYSTEM*********");
				System.out.println("                              **************************************************************************************************************");
				System.out.println("**************************************************************************************************************************************************************************");

				System.exit(0);
			}// Choice_Switch
		} // Main_While

	}
}
