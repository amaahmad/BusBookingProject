package com.cg.obtrs.service;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.obtrs.dao.BookingDAO;
import com.cg.obtrs.dao.BookingDAOImpl;
import com.cg.obtrs.dao.StaticEntityManager;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.exception.CustomException;

public class BookingServiceImpl implements BookingService {
	BookingDAO bookingdao = new BookingDAOImpl();

	@Override
	public String bookSeat(List<String> passengerNames, int age, long cardNumber, int cardCvv, int busId,
			float totalFare) throws CustomException {
		return bookingdao.bookSeat(passengerNames, age, cardNumber, cardCvv, busId, totalFare);
	}

	@Override
	public String generateTicket(int busId, int bookingId) throws CustomException {
		EntityManager manager = StaticEntityManager.getManager();
		BookingDTO bookingDto = manager.find(BookingDTO.class, bookingId);
		BusDTO busDto = manager.find(BusDTO.class, busId);
		if (bookingDto != null && busDto != null)
			return bookingdao.generateTicket(busId, bookingId);
		else
			throw new CustomException("Invalid Booking ID or Bus Id");
	}

	@Override
	public float displayFare(int age, int busId) throws CustomException {
		EntityManager manager = StaticEntityManager.getManager();

		BusDTO busDto = manager.find(BusDTO.class, busId);
		if (busDto != null)
			return bookingdao.displayFare(age, busId);
		else
			throw new CustomException("Invalid Bus Id");

	}

	@Override
	public String cancelBooking(int bookingId, int busId) throws CustomException {
		EntityManager manager = StaticEntityManager.getManager();
		BookingDTO bookingDto = manager.find(BookingDTO.class, bookingId);
		BusDTO busDto = manager.find(BusDTO.class, busId);
		if (bookingDto != null && busDto != null)
			return bookingdao.generateTicket(busId, bookingId);
		else
			throw new CustomException("Invalid Booking ID or Bus Id");

	}

	@Override
	public float refundMoney(int bookingId) throws CustomException {
		return bookingdao.refundMoney(bookingId);
	}

}
