package com.cg.obtrs.dto;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

import org.hibernate.annotations.IndexColumn;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "Booking")
public class BookingDTO 
{   
	@Id
	@Column(name = "BOOKING_ID")
    private int bookingId;
	@Column(name = "BUS_ID")
	private int busId;
    @ElementCollection
	private List<String> passengerNames = new ArrayList<>();
	@Column(name = "SEATS_BOOKED")
	private Integer seatsBooked;
	@Column(name = "TOTAL_FARE")
	private float totalFare;
	
	public BookingDTO()
	{
		
	}
	
	public BookingDTO(int busId, List<String> passengerNames, Integer seatsBooked, float totalFare, int bookingId) {
		super();
		this.busId = busId;
		this.passengerNames = passengerNames;
		this.seatsBooked = seatsBooked;
		this.totalFare =totalFare;
		this.bookingId = bookingId;
	}


	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	
	public Integer getSeatsBooked() {
		return seatsBooked;
	}
	
	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}
	public List<String> getPassengerNames() {
		return passengerNames;
	}
	public void setPassengerNames(List<String> passengerNames) {
		this.passengerNames = passengerNames;
	}


	public float getTotalFare() {
		return totalFare;
	}


	public void setTotalFare(float totalFare) {
		this.totalFare = totalFare;
	}

   
	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	@Override
	public String toString() {
		return "BookingDTO [busId=" + busId + ", passengerNames=" + passengerNames + ", seatsBooked=" + seatsBooked
				+ ", totalFare=" + totalFare + "]";
	}

	

}