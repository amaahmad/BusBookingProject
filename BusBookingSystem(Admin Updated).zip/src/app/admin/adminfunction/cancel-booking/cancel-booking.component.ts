import { Component, OnInit } from '@angular/core';
import { BookingService } from 'src/app/booking.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-cancel-booking',
  templateUrl: './cancel-booking.component.html',
  styleUrls: ['./cancel-booking.component.css']
})
export class CancelBookingComponent implements OnInit {
  flag1:any;
  constructor(private bookingSer:BookingService,private router:Router) { }
  cancelticket = new FormGroup({
    bookingId: new FormControl('')
  })
 
    ngOnInit(): void 
    {
      this.bookingSer.getBooking();
    }
  cancelTicket()
  {
    let bookingId=this.cancelticket.get('bookingId').value;
    let k=0;
    for(let i=0;i<this.bookingSer.bookingDb.length;i++) 
    {
      if (this.bookingSer.bookingDb[i].id==bookingId)
      {     
        this.bookingSer.deleteBooking(bookingId).subscribe(data=>{console.log(data)});
        this.bookingSer.flag=true;
      }     
    }
    if (this.bookingSer.flag) 
    {
      this.flag1=true;
    }
  }

}
