import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bus } from 'src/app/Bus';
import { FormGroup, FormControl } from '@angular/forms';
import { BusService } from 'src/app/bus.service';

@Component({
  selector: 'app-update-boarding-time',
  templateUrl: './update-boarding-time.component.html',
  styleUrls: ['./update-boarding-time.component.css']
})
export class UpdateBoardingTimeComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;
  constructor(private busSer:BusService,private router:Router) { }
  updateBoarding = new FormGroup({
    busId : new FormControl(''),
    boardingTime : new FormControl('')
  })
  ngOnInit(): void {
   this.busSer.getBus();
  }
  updateBoardingTime()
  {
    let busId=this.updateBoarding.get('busId').value;
    let boardingTime=this.updateBoarding.get('boardingTime').value;
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
       if(this.busSer.busDb[i].id==busId)
       {
         if(this.busSer.busDb[i].boardingTime!=boardingTime)
         {
         this.busSer.busDb[i].boardingTime=boardingTime;
         this.tempBus=this.busSer.busDb[i];
         this.busSer.updateBus(this.busSer.busDb[i].id,this.tempBus).subscribe(data=>{console.log(data)});
         this.flag1=true;
         }
         else
         window.alert("Entered time is same as old one. Please enter new time.")
       }
    } 
  
  }
}


