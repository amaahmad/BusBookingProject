import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Bus } from 'src/app/Bus';

@Component({
  selector: 'app-update-drop-time',
  templateUrl: './update-drop-time.component.html',
  styleUrls: ['./update-drop-time.component.css']
})
export class UpdateDropTimeComponent implements OnInit {
   flag1:boolean;
   tempBus:Bus;
  constructor(private busSer:BusService,router:Router) { }
  updateDroptime=new FormGroup({
    busId:new FormControl,
    dropTime:new FormControl
  })
  ngOnInit(): void {
    this.busSer.getBus();
  }
 
  updateDropTime(){
    let busId=this.updateDroptime.get('busId').value;
    let dropTime=this.updateDroptime.get('dropTime').value;
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
      if(this.busSer.busDb[i].id==busId)
      {
        this.busSer.busDb[i].dropTime=dropTime;
        this.tempBus=this.busSer.busDb[i];
        this.busSer.updateBus(this.busSer.busDb[i].id,this.tempBus).subscribe(data=>(console.log(data)));
        this.flag1=true;
      }
    }
  }

}
