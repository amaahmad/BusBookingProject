import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDropTimeComponent } from './update-drop-time.component';

describe('UpdateDropTimeComponent', () => {
  let component: UpdateDropTimeComponent;
  let fixture: ComponentFixture<UpdateDropTimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateDropTimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDropTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
