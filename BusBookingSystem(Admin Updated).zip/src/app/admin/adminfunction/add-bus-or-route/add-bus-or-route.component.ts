
import { Component, OnInit } from '@angular/core';
import { Bus } from 'src/app/Bus';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-add-bus-or-route',
  templateUrl: './add-bus-or-route.component.html',
  styleUrls: ['./add-bus-or-route.component.css']
})



export class AddBusOrRouteComponent implements OnInit {
  flag1:any;
  bus: Bus[]=[];
  constructor(private busSer:BusService,private router:Router) { }
  busDetails = new FormGroup({
  id : new FormControl(''),
  sourceStation : new FormControl(''),
  destinationStation : new FormControl(''),
  boardingTime : new FormControl(''),
  dropTime : new FormControl(''),
  busType : new FormControl(''),
  totalSeats : new FormControl(''),
  fare : new FormControl('')
  })
 
    ngOnInit(): void 
    {
      this.busSer.getBus();
    }
  busAdd()
  {
    let sourceStation=this.busDetails.get('sourceStation').value;
    let destinationStation=this.busDetails.get('destinationStation').value;
    let boardingTime=this.busDetails.get('boardingTime').value;
    let dropTime=this.busDetails.get('dropTime').value;
    let busType=this.busDetails.get('busType').value;
    let totalSeats=this.busDetails.get('totalSeats').value;
    let fare=this.busDetails.get('fare').value;
    let id=this.busDetails.get('id').value;
    let SeatNo=null;
    let seatsBooked=null;
    // for(var i=0; i<this.busSer.busDb.length;i++)
    // {
    //   if(this.busSer.busDb == busId)
    // }

    let tempAdd: Bus = new Bus(id,sourceStation,destinationStation,boardingTime,dropTime,busType,totalSeats,fare,SeatNo,seatsBooked);
    this.busSer.addBus(tempAdd).subscribe(data=>{console.log(data)}); 
    this.bus[0]= tempAdd;
  }

}
