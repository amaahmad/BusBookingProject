import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { BusService } from '../bus.service';
import { Booking } from '../Booking';

@Component({
  selector: 'app-generate-ticket',
  templateUrl: './generate-ticket.component.html',
  styleUrls: ['./generate-ticket.component.css']
})
export class GenerateTicketComponent implements OnInit {
  booking:Booking[]=[];
  constructor(private bookingSer:BookingService,private router:Router,private busSer:BusService) { }
  generateticket = new FormGroup({
    busId: new FormControl(''),
    bookingId: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.bookingSer.getBooking();
      this.busSer.getBus();
    }
  generateTicket()
  {
  let busId = this.generateticket.get('busId').value;
  let bookingId=this.generateticket.get('bookingId').value;
    let k=0;
    for(let i=0;i<this.bookingSer.bookingDb.length;i++) 
    {
      if (this.bookingSer.bookingDb[i].busId == busId&&this.bookingSer.bookingDb[i].id==bookingId)
      {     
        this.booking[0]=this.bookingSer.bookingDb[i];
        this.bookingSer.flag=true;
      }     
    }
  }

}
