import { Component, OnInit } from '@angular/core';
import {BusService} from './bus.service';
import {Bus} from './Bus';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  
})
export class AppComponent implements OnInit 
{
  title = 'BusBookingManagementSystem';
  flag1:any;
  constructor()
  {
  }
  ngOnInit()
  {
  }
  run()
  {
    this.flag1==true;
  }

}
