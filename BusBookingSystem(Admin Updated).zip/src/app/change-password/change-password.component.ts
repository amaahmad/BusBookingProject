import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { BusService } from '../bus.service';
import { FormGroup, FormControl } from '@angular/forms';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit 
{
  flag1:boolean;
  tempCustomer:any;
  constructor(private custSer:CustomerService,private router:Router) { }
  changepassword = new FormGroup({
    customerEmail: new FormControl(''),
    oldPassword: new FormControl(''),
    newPassword: new FormControl(''),
    reNewPassword: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  changePassword()
  {
  let customerEmail = this.changepassword.get('customerEmail').value;
  let oldPassword=this.changepassword.get('oldPassword').value;
  let newPassword=this.changepassword.get('newPassword').value;
  let reNewPassword=this.changepassword.get('reNewPassword').value;
    for(let i=0;i<this.custSer.customerDb.length;i++) 
    {
      if (this.custSer.customerDb[i].customerEmail == customerEmail)
      {     
        if(this.custSer.customerDb[i].customerPassword==oldPassword)
        {
          if(newPassword==reNewPassword)
          {
            this.custSer.customerDb[i].customerPassword=newPassword;
            this.tempCustomer=this.custSer.customerDb[i];
            this.custSer.updateCustomer(this.custSer.customerDb[i].id,this.tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true;
          }
        }
      }     
    }
    if (this.custSer.flag) 
    {
      this.flag1=true;
      this.router.navigateByUrl("/edit-profile");
    }
  }
}