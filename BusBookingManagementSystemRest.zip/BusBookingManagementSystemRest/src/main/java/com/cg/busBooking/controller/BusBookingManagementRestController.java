package com.cg.busBooking.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.busBooking.dto.Booking;
import com.cg.busBooking.dto.Bus;
import com.cg.busBooking.dto.Customer;
import com.cg.busBooking.service.BookingService;
import com.cg.busBooking.service.BusService;
import com.cg.busBooking.service.CustomerService;
@CrossOrigin(origins="local:4200")
@RestController
public class BusBookingManagementRestController 
{
	@Autowired
	private BusService busService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private BookingService bookingService;
	
	//Fetching Data
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(
			value = "/bus",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public List<Bus> getAllBus()
	{
		return busService.getAllBus();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(
			value = "/booking",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public List<Booking> getAllBooking()
	{
		return bookingService.getAllBooking();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(
			value = "/customer",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public List<Customer> getAllCustomer()
	{
		return customerService.getAllCustomer();
	}
	//Fetching Data by ID
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(
			value = "/bus/{busId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
    public Optional<Bus> getBusById(@PathVariable() Integer busId)
	{
        return busService.getBusById(busId);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(
			value = "/booking/{bookingId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public Optional<Booking> getBookingById(@PathVariable() Integer bookingId)
	{
        return bookingService.getBookingById(bookingId);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(
			value = "/customer/{customerId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public Optional<Customer> getCustomerById(@PathVariable() Integer customerId)
	{
        return customerService.getCustomerById(customerId);
    }

	//Adding Data to DB
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(
			value = "/bus/new",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
    public Bus addNewBus(@RequestBody() Bus newBus)
	{
        return busService.addNewBus(newBus);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(
			value = "/booking/new",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public Booking addNewBooking(@RequestBody() Booking newBooking)
	{
        return bookingService.addNewBooking(newBooking);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(
			value = "/customer/new",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public Customer addNewCustomer(@RequestBody() Customer newCustomer)
	{
        return customerService.addNewCustomer(newCustomer);
    }

	//Delete By Id
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(
			value = "/bus/{busId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
    public void deleteBusById(@PathVariable() Integer busId)
	{
         busService.deleteBusById(busId);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(
			value = "/booking/{bookingId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public void deleteBookingById(@PathVariable() Integer bookingId)
	{
         bookingService.deleteBookingById(bookingId);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(
			value = "/customer/{customerId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public void deleteCustomerById(@PathVariable() Integer customerId)
	{
         customerService.deleteCustomerById(customerId);
    }
	
	//Update By Id
	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping(
			value = "/bus/{busId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
    public Bus updateBusById(@RequestBody() Bus newBus, @PathVariable() Integer busId)
	{
        return busService.updateBusById(newBus,busId);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping(
			value = "/booking/{bookingId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public Booking updateBookingById(@RequestBody() Booking newBooking,@PathVariable() Integer bookingId)
	{
        return bookingService.updateBookingById(newBooking,bookingId);
    }
	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping(
			value = "/customer/{customerId}",
			headers = "Accept=application/json",
			produces = "application/json")
	@ResponseBody
	public Customer updateCustomerById(@RequestBody() Customer newCustomer,@PathVariable() Integer customerId)
	{
        return customerService.updateCustomerById(newCustomer,customerId);
    }
}
