package com.cg.busBooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.busBooking.dao.BookingDao;
import com.cg.busBooking.dao.BusDao;
import com.cg.busBooking.dto.Booking;
import com.cg.busBooking.exception.NotFoundException;

@Service
public class BookingServiceImpl implements BookingService
{
	@Autowired
	private BookingDao bookingDao;

	@Override
	public List<Booking> getAllBooking() 
	{
		return (List<Booking>) bookingDao.findAll();
	}

	@Override
	public Optional<Booking> getBookingById(Integer bookingId) 
	{
		return bookingDao.findById(bookingId);
	}

	@Override
	public Booking addNewBooking(Booking newBooking) 
	{
		return bookingDao.save(newBooking);
	}

	@Override
	public Booking updateBookingById(Booking newBooking, Integer bookingId) 
	{
		if(bookingDao.existsById(bookingId))
			return bookingDao.save(newBooking);
		else
			throw new NotFoundException("Cant find Id");
	}

	@Override
	public void deleteBookingById(Integer bookingId) 
	{
		bookingDao.deleteById(bookingId);		
	}
}
