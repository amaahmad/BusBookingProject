package com.cg.busBooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.busBooking.dao.CustomerDao;
import com.cg.busBooking.dto.Customer;
import com.cg.busBooking.exception.NotFoundException;
@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	private CustomerDao customerDao;

	@Override
	public List<Customer> getAllCustomer()
	{
		return (List<Customer>) customerDao.findAll();
	}

	@Override
	public Optional<Customer> getCustomerById(Integer customerId) 
	{
		return customerDao.findById(customerId);
	}

	@Override
	public Customer addNewCustomer(Customer newCustomer) 
	{
		return customerDao.save(newCustomer);
	}

	@Override
	public void deleteCustomerById(Integer customerId) 
	{
		customerDao.deleteById(customerId);

	}

	@Override
	public Customer updateCustomerById(Customer newCustomer, Integer customerId) 
	{
		if(customerDao.existsById(customerId))
		{
			return customerDao.save(newCustomer);
		}
		else
			throw new NotFoundException("Cant find customer");		
	}

}
