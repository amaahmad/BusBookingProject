package com.cg.busBooking.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.busBooking.dto.Bus;

public interface BusDao extends CrudRepository<Bus,Integer>
{
	
}
