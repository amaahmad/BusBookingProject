package com.cg.busBooking.service;

import java.util.List;
import java.util.Optional;

import com.cg.busBooking.dto.Bus;

public interface BusService 
{
	List<Bus> getAllBus();
	Optional<Bus> getBusById(Integer busId);
	Bus addNewBus(Bus newBus);
	Bus updateBusById(Bus newBus, Integer busId);
	void deleteBusById(Integer busId);
}
