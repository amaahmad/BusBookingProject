package com.cg.busBooking.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.busBooking.dto.Booking;

public interface BookingDao extends CrudRepository<Booking,Integer> 
{

}
