package com.cg.busBooking.dto;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "booking")
public class Booking 
{
    @Id
    @Column(name = "booking_id")
	private int bookingId;
    @Column(name = "bus_id")
	private int busId;
    @Column(name= "customer_id")
    private int customerId;
    @Column(name = "passenger_names")
	private String passengerNames;
    @Column(name = "seat_booked")
	private int seatBooked;
	@Column(name = "passenger_email")
	private String passengerEmail;
	@Column(name = "total_fare")
	private int totalFare;
	@Column(name = "feedback")
	private String feedBack;
	private int rating;

	private Booking() 
	{
		super();
	}

	private Booking(int bookingId, int busId,int customerId, String passengerNames, int seatBooked, String passengerEmail, int totalFare,
			String feedBack, int rating) 
	{
		super();
		this.bookingId = bookingId;
		this.busId = busId;
		this.customerId=customerId;
		this.passengerNames = passengerNames;
		this.seatBooked = seatBooked;
		this.passengerEmail = passengerEmail;
		this.totalFare = totalFare;
		this.feedBack = feedBack;
		this.rating = rating;
	}
	
	public int getBookingId() 
	{
		return bookingId;
	}
	public void setBookingId(int bookingId) 
	{
		this.bookingId = bookingId;
	}

	public int getBusId() 
	{
		return busId;
	}
	public void setBusId(int busId) 
	{
		this.busId = busId;
	}
	
	public int getCustomerId() 
	{
		return customerId;
	}
	public void setCustomerId(int customerId) 
	{
		this.customerId = customerId;
	}

	public String getPassengerNames() 
	{
		return passengerNames;
	}
	public void setPassengerNames(String passengerNames) 
	{
		this.passengerNames = passengerNames;
	}

	public int getSeatBooked() 
	{
		return seatBooked;
	}
	public void setSeatBooked(int seatBooked) 
	{
		this.seatBooked = seatBooked;
	}

	public String getPassengerEmail() 
	{
		return passengerEmail;
	}
	public void setPassengerEmail(String passengerEmail) 
	{
		this.passengerEmail = passengerEmail;
	}

	public int getTotalFare() 
	{
		return totalFare;
	}
	public void setTotalFare(int totalFare) 
	{
		this.totalFare = totalFare;
	}

	public String getFeedBack() 
	{
		return feedBack;
	}
	public void setFeedBack(String feedBack) 
	{
		this.feedBack = feedBack;
	}

	public int getRating() 
	{
		return rating;
	}
	public void setRating(int rating) 
	{
		this.rating = rating;
	}

	@Override
	public String toString() 
	{
		return "Booking [bookingId=" + bookingId + ", busId=" + busId + ", customerId=" + customerId + ", passengerNames="
				+ passengerNames + ", seatBooked=" + seatBooked + ", passengerEmail=" + passengerEmail
				+ ", totalFare=" + totalFare + ", feedBack=" + feedBack + ", rating=" + rating + "]";
	}

}
