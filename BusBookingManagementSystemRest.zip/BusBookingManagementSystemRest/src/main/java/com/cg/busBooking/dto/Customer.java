package com.cg.busBooking.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer
{
	@Id
	@Column(name = "customer_id")
	private int customerId;
	@Column(name = "customer_name")
	private String customerName;
	@Column(name = "customer_phone_no")
	private String customerPhoneNumber;
	@Column(name = "customer_email")
	private String customerEmail;
	@Column(name = "customer_username")
	private String customerUserName;
	@Column(name = "customer_password")
	private String customerPassword;
	private int age;
	public String getCustomerName() 
	{
		return customerName;
	}
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	public String getCustomerPhoneNumber() 
	{
		return customerPhoneNumber;
	}
	public void setCustomerPhoneNumber(String customerPhoneNumber) 
	{
		this.customerPhoneNumber = customerPhoneNumber;
	}
	public String getCustomerEmail() 
	{
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) 
	{
		this.customerEmail = customerEmail;
	}
	public int getCustomerId() 
	{
		return customerId;
	}
	public void setId(int customerId) 
	{
		this.customerId = customerId;
	}
	public String getCustomerUserName() 
	{
		return customerUserName;
	}
	public void setCustomerUserName(String customerUserName) 
	{
		this.customerUserName = customerUserName;
	}
	public String getCustomerPassword() 
	{
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) 
	{
		this.customerPassword = customerPassword;
	}
	public int getAge() 
	{
		return age;
	}
	public void setAge(int age) 
	{
		this.age = age;
	}
	public Customer(String customerName, String customerPhoneNumber, String customerEmail, int customerId,
			String customerUserName, String customerPassword, int age) 
	{
		super();
		this.customerName = customerName;
		this.customerPhoneNumber = customerPhoneNumber;
		this.customerEmail = customerEmail;
		this.customerId = customerId;
		this.customerUserName = customerUserName;
		this.customerPassword = customerPassword;
		this.age = age;
	}
	private Customer() 
	{
		super();
	}
	@Override
	public String toString() 
	{
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerPhoneNumber="
				+ customerPhoneNumber + ", customerEmail=" + customerEmail + ", customerUserName=" + customerUserName
				+ ", customerPassword=" + customerPassword + ", age=" + age + "]";
	}
}