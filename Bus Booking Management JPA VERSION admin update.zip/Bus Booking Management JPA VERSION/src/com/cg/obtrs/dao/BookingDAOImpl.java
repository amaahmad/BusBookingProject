package com.cg.obtrs.dao;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;



import com.cg.obtrs.entities.BookingEntity;
import com.cg.obtrs.entities.BusEntity;
import com.cg.obtrs.exception.CustomException;

public class BookingDAOImpl implements BookingDAO {
	
	static int seatCounter = 0;
	
//Function that books seats as specified by the passenger 
	public String bookSeat(List<String> passengerNames,int age, long cardNumber, int cardCvv, int busId, float totalFare)
			throws CustomException {
		EntityManager manager =  StaticEntityManager.getManager();
		BookingEntity bookingentity = new BookingEntity();
		Random random = new Random();
		String seatNo = "";
		int bookingId = random.nextInt(10000);
		bookingentity.setPassengerNames(passengerNames);
		bookingentity.setSeatsBooked(passengerNames.size());
		bookingentity.setTotalFare(totalFare);
		bookingentity.setBusId(busId);
		bookingentity.setBookingId(bookingId);
		manager.getTransaction().begin();
	    BusEntity busentity = manager.find(BusEntity.class, busId);
	    int totalPassengers  =passengerNames.size();
	    while(totalPassengers>0)
	    {
	    if(busentity.getTotalSeats()/2 >= seatCounter)
	     seatNo = seatNo +","+ seatCounter+++"A"; 
	    else
	     seatNo = seatNo +","+seatCounter+++"B";
	    totalPassengers--;
	    }
		bookingentity.setSeatNo(seatNo);
	   busentity.setSeatsBooked(busentity.getSeatsBooked() + passengerNames.size());
		manager.persist(bookingentity);
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		return "Booking Confirmed" + " " + "Your Booking Id is : " + bookingId;
	}

	@Override
	/// Function to generate Ticket 
	public String generateTicket(int busId, int bookingId) throws CustomException 
	{  
	    EntityManager manager = null;
 		try {
		List<String> passengerNames = new ArrayList<>();
		 manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		BookingEntity bookingentity = manager.find(BookingEntity.class, bookingId);
		//BookingDTO bookingDto = StaticDb.bookingList.get(bookingId);
		 passengerNames = bookingentity.getPassengerNames();
		int seatsBooked = bookingentity.getSeatsBooked();
		float fare = bookingentity.getTotalFare();
		BusEntity busentity = manager.find(BusEntity.class, busId);
		String source = busentity.getSourceStation();
		String destination = busentity.getDestinationStation();
		String seatNo = bookingentity.getSeatNo();
		LocalDateTime boardingTime = busentity.getBoardingTime();
		LocalDateTime dropTime = busentity.getDropTime();
		manager.getTransaction().commit();
		 DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a"); 
		return "\n\t\tPassenger Names=" + passengerNames + "\n\t\tSeatsBooked=" + seatsBooked+ "\n\t\tSeat Numbers=" + seatNo + "\n\t\tBooking Id=" + bookingId
				+ "\n\t\tDeparture Station=" + source + " " + "\n\t\tArrival station=" + destination  + "\n\t\tFare=" + "Rs." + fare
				+ "\n\t\tBoardingTime=" + boardingTime.format(format) + " " + "\n\t\tDrop Time=" + dropTime.format(format);
		}
		finally
		{  if(manager!=null)
			manager.close();
			StaticEntityManager.closeEntityManagerFactory();
		}
	}

	//Function that refunds money in case of cancellation.
	public float refundMoney(int bookingId) throws CustomException
	{
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		BookingEntity bookingentity = manager.find(BookingEntity.class, bookingId);
		float totalFare = bookingentity.getTotalFare();
		totalFare = totalFare-(0.20f*totalFare);
		manager.remove(bookingentity);
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		 return totalFare;
	}
    
	//Function that displays the  Discounted Fare Amount for selected bus
	@Override
	public float displayFare(int age, int busId) throws CustomException 
	{
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		BusEntity busentity = manager.find(BusEntity.class, busId);
		float busFare, discountedFare = 0;
		busFare = busentity.getFare();
		if (age < 8) {
			float discount = (0.60f * busFare);
			discountedFare = busFare - discount;
		} else {
			discountedFare = busFare;
		}
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		return discountedFare;
	}
	
//    //Function to check for seat availability in selected bus. Already available in CustomerService
//	 public Integer checkSeatAvailability(int busId) throws CustomException 
//	 {
//		   BusDTO busDto = StaticDb.busList.get(busId);
//           int totalSeats = busDto.getTotalSeats();
//           int seatsBooked = busDto.getSeatsBooked();
//           int seatsAvailable = totalSeats-seatsBooked;
//           return seatsAvailable;
//	 }
	
	//Function to cancel the bus booking if the customer wants.
	@Override
	public String cancelBooking(int bookingId, int busId) throws CustomException 
	{    
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		 BusEntity busentity = manager.find(BusEntity.class, busId);
		 BookingEntity bookingentity = manager.find(BookingEntity.class, bookingId);
		int noOfPassengers =  bookingentity.getSeatsBooked();
		busentity.setSeatsBooked(busentity.getSeatsBooked()- noOfPassengers);
		bookingentity.setSeatsBooked(0);
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		return "\t\t************Cancellation Successfull***********\n" + "\t\t**********Refund has be initiated************";
	}
	
	//

}
