package com.cg.obtrs.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StaticEntityManager 
{
   private static EntityManager manager;
   private static EntityManagerFactory factory;
public static EntityManager getManager() 
{  
	factory = getFactory();
  manager =	factory.createEntityManager();
	return manager;
}

public static EntityManagerFactory getFactory() 
{    
   factory = Persistence.createEntityManagerFactory("BookingUnit");
	return factory;
}

public static void closeEntityManagerFactory()
{
	if(factory!=null)
		factory.close();
}
   
}
