package com.cg.obtrs.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.dto.CustomerDTO;
import com.cg.obtrs.entities.BusEntity;
import com.cg.obtrs.entities.CustomerEntity;
import com.cg.obtrs.exception.CustomException;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public String customerSignUp(String name, long phoneNumber, String email, int custId, String userName,
			String password, int age) throws CustomException {
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		CustomerEntity customer = new CustomerEntity();
		customer.setCustName(name);
		customer.setCustPhoneNumber(phoneNumber);
		customer.setCustEmail(email);
		customer.setCustID(custId);
		customer.setCustUserName(userName);
		customer.setCustPassword(password);
		customer.setAge(age);
		manager.persist(customer);
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		return "\n\n\t\t\t\t****************Signup Successfull********************";
	}

	@Override
	public String customerLoginIn(String userName, String password) throws CustomException {
		int flag = 0;
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from Customer p");
		List<CustomerEntity> custList = query.getResultList();
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		for (CustomerEntity cust : custList) {
			if (cust.getCustUserName().equalsIgnoreCase(userName) && cust.getCustPassword().equals(password)) {
				flag = 1;
				break;
			}
		}
		if (flag == 1)
			return "\n\n\n\t\t\t\t*****************Login Successfull*******************" + "\n\n\t\t\t\t\t\t\tOPTIONS";
		else
			throw new CustomException("Username or Password is incorrect");
	}

	@Override
	public boolean changePassword(String custEmail, String currentPassword, String newPassword) throws CustomException {
		int flag = 0;
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from Customer p");
		List<CustomerEntity> custList = query.getResultList();
		for (CustomerEntity cust : custList) {
			if (cust.getCustEmail().equalsIgnoreCase(custEmail) && cust.getCustPassword().equals(currentPassword)) {
				flag = 1;
				cust.setCustPassword(newPassword);
				break;
			}
		}
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		if (flag == 1)
			return true;
		else
			throw new CustomException("SORRY! INVALID DETAILS! PASSWORD CANNOT BE CHANGED SUCCESSFULLY");
	}

	@Override
	public List<BusEntity> searchBus(String sourceStation, String destinationStation) throws CustomException {
		List<BusEntity> searchList = new ArrayList<>();
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from BusEntity p");
		List<BusEntity> busList = query.getResultList();
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		for (BusEntity bus : busList) {
			if (bus.getSourceStation().equalsIgnoreCase(sourceStation)
					&& bus.getDestinationStation().equalsIgnoreCase(destinationStation)) {
				searchList.add(bus);

			}
		}
		if (searchList.isEmpty())
			throw new CustomException("No buses Found");
		return searchList;
	}

	public Integer checkSeatAvailability(int busId) throws CustomException {
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		BusEntity busentity = manager.find(BusEntity.class, busId);
		int totalSeats = busentity.getTotalSeats();
		int seatsBooked = busentity.getSeatsBooked();
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		int seatsAvailable = totalSeats - seatsBooked;
		return seatsAvailable;
	}

	@Override
	public boolean validatePassword(String email, String userName) throws CustomException {
		int flag = 0;
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from Customer p");
		List<CustomerEntity> custList = query.getResultList();
		for (CustomerEntity cust : custList) {
			if (cust.getCustEmail().equalsIgnoreCase(email) && cust.getCustUserName().equalsIgnoreCase(userName)) {
				flag = 1;
				break;
			}
		}
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		if (flag == 1)
			return true;
		else
			return false;
	}

	@Override
	public boolean forgetPassword(String email, String userName, String newPassword) throws CustomException {
		int flag = 0;
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from Customer p");
		List<CustomerEntity> custList = query.getResultList();
		for (CustomerEntity cust : custList) {
			if (cust.getCustEmail().equalsIgnoreCase(email) && cust.getCustUserName().equalsIgnoreCase(userName)) {
				cust.setCustPassword(newPassword);
				flag = 1;
				break;
			}
		}
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		if (flag == 1)
			return true;
		else
			return false;
	}

	@Override
	public List<BusEntity> sortBusByDepartureTime(String sourceStation, String destinationStation) throws CustomException {
		ArrayList<BusEntity> sortBusList = new ArrayList<>();
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from BusEntity p");
		List<BusEntity> busList = query.getResultList();
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		for (BusEntity bus : busList) {
			if (bus.getSourceStation().equalsIgnoreCase(sourceStation)
					&& bus.getDestinationStation().equalsIgnoreCase(destinationStation)) {
				sortBusList.add(bus);

			}
		}
		if (sortBusList.isEmpty())
			throw new CustomException("NO BUSES FOUND");
		Collections.sort(sortBusList, BusEntity.departureComparator);
		return sortBusList;
	}

	@Override
	public List<BusEntity> sortBusByArrivalTime(String sourceStation, String destinationStation) throws CustomException {
		ArrayList<BusEntity> sortBusList = new ArrayList<BusEntity>();
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from BusEntity p");
		List<BusEntity> busList = query.getResultList();
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		for (BusEntity bus : busList) {
			if (bus.getSourceStation().equalsIgnoreCase(sourceStation)
					&& bus.getDestinationStation().equalsIgnoreCase(destinationStation)) {
				sortBusList.add(bus);

			}
		}
		if (sortBusList.isEmpty())
			throw new CustomException("NO BUSES FOUND");
		Collections.sort(sortBusList, BusEntity.arrivalComparator);
		return sortBusList;
	}

	@Override
	public String customerFeedback(String email, String feedBack, int rating) throws CustomException {
		int flag = 0;
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select b from Customer b");
		List<CustomerEntity> custList = query.getResultList();
		for (CustomerEntity cust : custList) {
			if (cust.getCustEmail().equalsIgnoreCase(email)) {
				flag = 1;
				cust.setFeedBack(feedBack);
				cust.setRating(rating);
				break;
			}
		}
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		if (flag == 1)
			return "\n\t\t******************FEEDBACK SUBMITTED SUCCESSFULLY********************";
		else
			throw new CustomException("EMAIL ID NOT FOUND!");

	}
}
