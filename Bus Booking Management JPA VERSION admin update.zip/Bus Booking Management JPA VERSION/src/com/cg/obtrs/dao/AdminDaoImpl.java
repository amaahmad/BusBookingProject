package com.cg.obtrs.dao;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.dto.CustomerDTO;
import com.cg.obtrs.entities.AdminEntity;
import com.cg.obtrs.entities.BookingEntity;
import com.cg.obtrs.entities.BusEntity;
import com.cg.obtrs.entities.CustomerEntity;
import com.cg.obtrs.exception.CustomException;


public class AdminDaoImpl implements AdminDAO {

    
    @Override
    public String adminSignUp(AdminDTO adminDto) {
        
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		AdminEntity adminentity = new AdminEntity();
		adminentity.setAdminName(adminDto.getAdminName());
		adminentity.setAdminPhoneNumber(adminDto.getAdminPhoneNumber());
		adminentity.setAdminEmail(adminDto.getAdminEmail());
		adminentity.setAdminID(adminDto.getAdminID());
		adminentity.setAdminUserName(adminDto.getAdminUserName());
		adminentity.setAdminPassword(adminDto.getAdminPassword());
		manager.persist(adminentity);
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		return "\n\n\t\t\t\t****************Signup Successfull********************";
    }

 

    @Override
    public String adminLoginIn(String userName, String password) {
        
    	int flag = 0;
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from AdminEntity p");
		List<AdminEntity> adminList = query.getResultList();
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		for (AdminEntity cust : adminList) {
			if (cust.getAdminUserName().equalsIgnoreCase(userName) && cust.getAdminPassword().equals(password)) {
				flag = 1;
				break;
			}
		}
		if (flag == 1)
			return "\n\n\n\t\t\t\t*****************Login Successfull*******************" + "\n\n\t\t\t\t\t\t\tOPTIONS";
		else
		     return "Invalid Username or password";
    }
    
    public String addBusOrRoute(int busId, String sourceStation, String destinationStation,LocalDateTime boardingTime, LocalDateTime dropTime, String busType, Integer totalSeats,
            Float fare){
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
            BusEntity newBus= new BusEntity();
            newBus.setBusId(busId);
            newBus.setSourceStation(sourceStation);
            newBus.setDestinationStation(destinationStation);
            newBus.setBoardingTime(boardingTime);
            newBus.setDropTime(dropTime);
            newBus.setFare(fare);
            newBus.setBusType(busType);
            newBus.setTotalSeats(totalSeats);
            manager.persist(newBus);
            manager.getTransaction().commit();
    		manager.close();
    		StaticEntityManager.closeEntityManagerFactory();
            return  "New Bus added [Bus ID : " + newBus.getBusId() + "]";
        
    }

 

    @Override
    public List<BookingEntity> generateReport() 
    {
    	List<BookingEntity> searchList = new ArrayList<>();
		EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		Query query = manager.createQuery("Select p from BookingEntity p");
		List<BookingEntity> bookingList = query.getResultList();
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		for (BookingEntity booking : bookingList) 
		{
			searchList.add(booking);
        }
	  return searchList;
    }
 

    @Override
    public String cancelBooking(int busId, int bookingId) throws CustomException {
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		 BusEntity busentity = manager.find(BusEntity.class, busId);
		 BookingEntity bookingentity = manager.find(BookingEntity.class, bookingId);
		int noOfPassengers =  bookingentity.getPassengerNames().size();
		busentity.setSeatsBooked(busentity.getSeatsBooked()-noOfPassengers);
		manager.getTransaction().commit();
		bookingentity.setSeatsBooked(bookingentity.getSeatsBooked()-noOfPassengers);
		manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
		return "\t\t************Cancellation Successfull***********\n" + "\t\t**********Refund has be initiated************";
    }

 

    

 

    @Override
    public String updateSourceStation(int busId, String sourceStation) 
    {
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
        BusEntity busentity= manager.find(BusEntity.class, busId);
        busentity.setSourceStation(sourceStation);
        manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
        return "Bus Details are updated successfully as per the Source Station";
    }

 

    @Override
    public String updateDestinationStation(int busId, String destinationStation) 
    {
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
	     BusEntity busentity= manager.find(BusEntity.class, busId);
        busentity.setDestinationStation(destinationStation);
        manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
        return "Bus Details are updated successfully as per the Destination Station";
    
    }

 

    @Override
    public String updateBoardingTime(int busId, LocalDateTime boardingTime) 
    {
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		BusEntity busentity= manager.find(BusEntity.class, busId);
        busentity.setBoardingTime(boardingTime);
        manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
        return "Bus Details are updated successfully as per the Boarding Time";
    }

 

    @Override
    public String updateDropTime(int busId, LocalDateTime dropTime) 
    {
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
		BusEntity busentity= manager.find(BusEntity.class, busId);
        busentity.setDropTime(dropTime);
        manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
        return "Bus Details are updated successfully as per the Drop Time";
    }

 

    @Override
    public String updateBustype(int busId, String busType) 
    {
    	EntityManager manager = StaticEntityManager.getManager();
		manager.getTransaction().begin();
	   BusEntity busentity= manager.find(BusEntity.class, busId);
        busentity.setBusType(busType);
        manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
        return "Bus Details are updated successfully as per the Bus Type";
    }

 

    @Override
    public String updateTotalSeats(int busId, int totalSeats) 
    {
    EntityManager manager = StaticEntityManager.getManager();
	manager.getTransaction().begin();
	 BusEntity busentity= manager.find(BusEntity.class, busId);
        busentity.setTotalSeats(totalSeats);
        manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
        return "Bus Details are updated successfully as per the number of seats";
    }

 

    @Override
    public String updateFare(int busId, Float fare) 
    { 
    	EntityManager manager = StaticEntityManager.getManager();
	manager.getTransaction().begin();
	 BusEntity busentity= manager.find(BusEntity.class, busId);
        busentity.setFare(fare);
        manager.getTransaction().commit();
		manager.close();
		StaticEntityManager.closeEntityManagerFactory();
        return "Bus Details are updated successfully as per the bus Fare";
    
    }
}