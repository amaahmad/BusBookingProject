package com.cg.obtrs.validation;

import java.util.regex.Pattern;

public class Validation {
	public boolean isValidName(String name) {
		String namePattern = "^[A-Z][a-z]{3,15}$";
		if (Pattern.matches(namePattern, name))
			return true;
		else
		    return false;
	}

	public boolean isValidUserName(String userName) {
		String userNamePattern = "^[a-z0-9_-]{3,15}$";
		if (Pattern.matches(userNamePattern, userName))
			return true;
		else
			return false;
	}

	public boolean isValidPassword(String password) {
		String passwordPattern = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		if (Pattern.matches(passwordPattern, password))
			return true;
		else
			return false;
	}

	public boolean isValidEmail(String email) {
		String emailPattern = "[_A-Za-z0-9.]*+@+[A-Za-z][A-Za-z]{4,10}+.+[A-Za-z][A-Za-z]{2,3}";
		if (Pattern.matches(emailPattern, email))
			return true;
		else
			return false;
	}

	public boolean isValidPhoneNo(Long phoneNo) {
		String phneNo = phoneNo.toString();
		String phneNoPattern = "[6-9][0-9]{9}";
		// if(phoneNo.length()==10)
		if (Pattern.matches(phneNoPattern, phneNo))
			return true;
		else

			return false;
	}

	public boolean isValidAge(int age) {
		if (age > 0 && age<=130)
			return true;
		else
			return false;
	}
	
	public boolean isCardValid(Long cardNumber)
	{
		String cardNumberString = String.valueOf(cardNumber);
		String cardPattern = "[0-9]{3,12}";
		if (Pattern.matches(cardPattern, cardNumberString))
			return true;
		else
		    return false;
	}

	public boolean isValidCvv(int cardCvv) {
		String cardCvvString = String.valueOf(cardCvv);
		String cardPattern = "[0-9]{3}";
		if (Pattern.matches(cardPattern, cardCvvString))
			return true;
		else
		    return false;
		
	}
}
