package com.cg.obtrs.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.obtrs.dto.BusDTO;

public class MyMain {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("BookingUnit");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		BusDTO bus = new BusDTO();
		em.find(BusDTO.class, 111);
		bus.setTotalSeats(45);
        em.getTransaction().commit();
        emf.close();
        em.close();
	}

}
