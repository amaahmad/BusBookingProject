package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class PhoneNumberTest {
         Validation validation = new Validation();
	@Test
	public void testPhoneNumber() {
	  boolean isPhoneNumberValid = validation.isValidPhoneNo(9454545477L);
	  assertTrue(isPhoneNumberValid); 
	}

}
