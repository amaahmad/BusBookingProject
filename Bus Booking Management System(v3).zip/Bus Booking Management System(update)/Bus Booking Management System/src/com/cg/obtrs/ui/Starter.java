package com.cg.obtrs.ui;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.exception.CustomException;
import com.cg.obtrs.service.AdminService;
import com.cg.obtrs.service.AdminServiceImpl;
import com.cg.obtrs.service.BookingService;
import com.cg.obtrs.service.BookingServiceImpl;
import com.cg.obtrs.service.CustomerService;
import com.cg.obtrs.service.CustomerServiceImpl;
import com.cg.obtrs.validation.Validation;

public class Starter {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean mainScreenFlag = true;
		CustomerService custService = new CustomerServiceImpl();
		BookingService bookingService = new BookingServiceImpl();
		AdminService adminService = new AdminServiceImpl();
		Validation validation = new Validation();
		while (mainScreenFlag) {
			System.out.println("************************ONLINE BUS TICKET RESERVATION SYSTEM***********************");
			System.out.println("\n\t\t1. To Continue as Admin");
			System.out.println("\n\t\t2. To Continue as User");
			System.out.println("\n\t\t3. Exit");
			int choice = input.nextInt();
			switch (choice) {
			case 1: // while(temp>0)
				System.out.println("1. Sign Up");
				System.out.println("2. LogIn");
				int adminChoice = input.nextInt();
				switch (adminChoice) {
				case 1:
					System.out.println("Enter Username");
					String userName = input.next();
					System.out.println("Enter Password");
					String password = input.next();
					System.out.println("Enter your Name");
					String name = input.next();
					System.out.println("Enter Phone number");
					long phoneNo = input.nextLong();
					System.out.println("Enter Email ID");
					String email = input.next();
					Random random = new Random();
					int custId = random.nextInt(1000);
					System.out.println(
							adminService.adminSignUp(new AdminDTO(name, phoneNo, email, custId, userName, password)));
					break;

				case 2:
					System.out.println("\n\n------FOR LOGIN-------\n");
					System.out.println("Enter Username");
					userName = input.next();
					System.out.println("Enter Password");
					password = input.next();
					System.out.println(adminService.adminLogin(userName, password));
					boolean flag = true;
					while (flag) {

						System.out.println("1. Add Bus or Route " + "\n 2. Generate reports " + "\n 3. Update Details"
								+ "\n 4. Cancel Booking" + "\n 5. Exit");
						int adminLoginChoice = input.nextInt();
						switch (adminLoginChoice) {
						case 1:
							System.out.println("Enter bus Id : ");
							int busId = input.nextInt();
							System.out.println("\n Enter Source Station : ");
							String sourceStation = input.next();
							System.out.println("\n Enter Destination Station : ");
							String destinationStation = input.next();
							System.out.println("Enter Boarding Time in yyyy-mm-dd-hr-min");
							LocalDateTime boardingTime = LocalDateTime.of(input.nextInt(), input.nextInt(),
									input.nextInt(), input.nextInt(), input.nextInt());
							System.out.println("Enter Drop Time in yyyy-mm-dd-hr-min");
							LocalDateTime dropTime = LocalDateTime.of(input.nextInt(), input.nextInt(), input.nextInt(),
									input.nextInt(), input.nextInt());
							System.out.println("\n Enter Bus Type : ");
							String busType = input.next();
							System.out.println("\n Enter total number of seats : ");
							int totalSeats = input.nextInt();
							System.out.println("\n Enter the fare: ");
							Float fare = input.nextFloat();
							System.out.println(adminService.addBusOrRoute(busId, sourceStation, destinationStation,
									boardingTime, dropTime, busType, totalSeats, fare));
							mainScreenFlag = false;
							break;

						case 2:
							System.out.println(adminService.generateReport());
							break;

						case 3:

							System.out.println("Enter the Bus Id:");
							busId = input.nextInt();
							boolean updateChoiceFlag = true;
							while (updateChoiceFlag) {
								System.out.println("Select the field you want to update : "
										+ "\n 1. Update Source Station : " + "\n 2. Update Destination Station : "
										+ "\n 3. Update Boarding Time : " + "\n 4. Update Drop Time : "
										+ "\n 5. Update Bus Type :" + "\n 6. Update Total Seats: "
										+ "\n 7. Update Bus fare : " + "\n 8. Exit. ");
								int updateChoice = input.nextInt();
								switch (updateChoice) {
								case 1:
									System.out.println("\n Enter Source Station : ");
									sourceStation = input.next();
									adminService.updateSourceStation(busId, sourceStation);
									break;

								case 2:
									System.out.println("\n Enter Destination Station : ");
									destinationStation = input.next();
									adminService.updateSourceStation(busId, destinationStation);
									break;

								case 3:
									System.out.println("Enter the boarding Time");
									// LocalDateTime boardingTime = input.
									break;

								case 4:

									System.out.println("Enter the drop time : ");
									break;

								case 5:
									System.out.println("Enter the bus Type:  ");
									busType = input.next();
									adminService.updateBustype(busId, busType);
									break;

								case 6:

									System.out.println("\n Enter total number of seats : ");
									totalSeats = input.nextInt();
									adminService.updateTotalSeats(busId, totalSeats);
									break;

								case 7:
									System.out.println("\n Enter the fare: ");
									fare = input.nextFloat();
									adminService.updateFare(busId, fare);
									break;

								case 8:
									updateChoiceFlag = false;
									break;

								default:
									System.out.println("Choose a valid Option");

								}// switch_UpdateChoice
							} // while

							break;

						case 4:

							System.out.println("Enter the bus Id : ");
							busId = input.nextInt();
							System.out.println("\n Enter the booking Id : ");
							int bookingId = input.nextInt();
							try {
								System.out.println(adminService.cancelBooking(busId, bookingId));
							} catch (CustomException e3) {
								// TODO Auto-generated catch block
								e3.printStackTrace();
							}

						case 5:
							flag = false;
							break;
						}
					}
					// adminChoiceLogin_Switch
					break;

				}// adminChoice_Switch
				break;

			case 2:
				System.out.println("\n\t1.New User? Sign Up");
				System.out.println("\n\t2.User Login");
				int custChoice = input.nextInt();
				switch (custChoice) {
				case 1:
					boolean userNameValidFlag = true;
					boolean emailFlag = true;
					boolean passwordFlag = true;
					boolean phonenoFlag = true;
					boolean nameFlag = true;
					String userName = "";
					String password = "";
					String name = "";
					long phoneNo = 0;
					String email = "";
					while (userNameValidFlag) {
						System.out.println(
								"Enter Username (username can contain letters, digits, underscore and must be have min. 3 characters)");
						userName = input.next();
						boolean checkUserName = validation.isValidUserName(userName);
						if (!checkUserName)
							System.out.println("Username is invalid!");
						else
							userNameValidFlag = false;
					}
					while (passwordFlag) {
						System.out.println(
								"Enter Password (password must contain an uppercase, a lowercase, a digit and a special character)");
						password = input.next();
						boolean checkPassword = validation.isValidPassword(password);
						if (!checkPassword)
							System.out.println("Password is invalid!");
						else
							passwordFlag = false;
					}
					while (nameFlag) {
						System.out.println("Enter your Name");
						name = input.next();
						boolean checkName = validation.isValidName(name);
						if (!checkName)
							System.out.println("Name is invalid!");
						else
							nameFlag = false;
					}
					while (phonenoFlag) {
						System.out.println("Enter Phone number");
						phoneNo = input.nextLong();
						boolean checkPhoneNo = validation.isValidPhoneNo(phoneNo);
						if (!checkPhoneNo)
							System.out.println("PhoneNo is invalid!");
						else
							phonenoFlag = false;
					}
					while (emailFlag) {
						System.out.println("Enter Email ID");
						email = input.next();
						boolean checkEmail = validation.isValidEmail(email);
						if (!checkEmail)
							System.out.println("Email is invalid!");
						else
							emailFlag = false;
					}
					Random random = new Random();
					int custId = random.nextInt(1000);
					try {
						System.out
								.println(custService.customerSignUp(name, phoneNo, email, custId, userName, password));
					} catch (CustomException e2) {

						System.out.println(e2.getMessage());
					}
					System.out.println("\n\n\n\t\t\t\t*****************Sign In to Continue*******************");
				case 2:
					boolean loginScreenFlag = true;
					while (loginScreenFlag) {
						int loginFailureFlag = 0;
						System.out.println("Please Enter Username");
						userName = input.next();
						System.out.println("Please Enter Password");
						password = input.next();
						try {
							System.out.println(custService.customerLoginIn(userName, password));
							loginScreenFlag = false;
						} catch (CustomException e1) {
							loginFailureFlag = 1;
							System.out.println(e1.getMessage());
						}
						if (loginFailureFlag > 0) {
							System.out.println("Forgot Password? Confirm by pressing 1 or press 0 to Login again");
							int userPasswordChoice = input.nextInt();
							switch (userPasswordChoice) {
							case 0:
								loginScreenFlag = true;
								break;
							case 1:
								System.out.println("Enter your email Id");
								email = input.next();
								System.out.println("Enter your userName");
								userName = input.next();
								boolean flagPasswordMatch = true;
								try {
									if (custService.validatePassword(email, userName)) {
										while (flagPasswordMatch) {
											System.out.println("Enter New Password");
											String newPassword = input.next();
											System.out.println("Re-enter New Password ");
											String renewPassword = input.next();
											if (newPassword.equals(renewPassword)) {
												flagPasswordMatch = false;
												if (custService.forgetPassword(email, userName, newPassword))
													System.out.println("Password changed successfully");
											} else {
												flagPasswordMatch = true;

												System.out.println("Password didn't matchh");
											}
										}
									}
								} catch (CustomException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								break;

							}
						}
						if (loginScreenFlag == false) {
							boolean passChangeFlag = true;
							while (passChangeFlag) {
								System.out.println("\n\t\t 1.Change Password");
								System.out.println("\n\t\t 2.Search for Bus");
								System.out.println("\n\t\t 3.Sort Bus Based on time");
								System.out.println("\n\t\t 4.Logout");
								int loginChoice = input.nextInt();
								switch (loginChoice) {
								case 1:
									System.out.println("Enter Your EmailID");
									String customerEmail = input.next();
									System.out.println("Enter currentPassword");
									String currentPassword = input.next();
									System.out.println("Enter New Password");
									String newPassword = input.next();
									try {
										boolean flag = custService.changePassword(customerEmail, currentPassword,
												newPassword);
										if (flag == true) {
											System.out.println(
													"\n\n\n\t\t\t\t*****************Password Changed Successfully*******************");
											System.out.println("You need to login again to continue.....");
											passChangeFlag = false;
											loginScreenFlag = true;
										}
									} catch (CustomException e) {
										System.out.println(e.getMessage());
									}

									break;
								case 2:
									boolean searchFlag = true;
									boolean sourceToDestinationFlag = true;
									while (sourceToDestinationFlag) {
										System.out.println("Enter Source Station");
										sourceStation = input.next();
										System.out.println("Enter Destination Station");
										String destinationStation = input.next();
										searchFlag = true;
										while (searchFlag) {
											try {
												System.out.println(
														custService.searchBus(sourceStation, destinationStation));
												System.out.println("\n\t\t1.To continue with the booking....");
												System.out.println("\n\t\t2.Change Source ---> Destination");
												int busIdChoice = input.nextInt();
												switch (busIdChoice) {
												case 1:
													boolean busFarePageFlag = true;
													System.out.println("Please enter BusId");
													int busId = input.nextInt();
													while (busFarePageFlag) {
														System.out.println("\n\t\t1.Display Fare");
														System.out.println("\n\t\t2.Check Seat Availability and Book Seats");
														System.out.println("\n\t\t3.Go back to choose Bus");
														
														int seatChoice = input.nextInt();
														switch (seatChoice) {
														case 1:
															boolean ageFlag = true;
															int passengerAge = 0;
															while (ageFlag) {
																System.out.println("Enter your Age");
																passengerAge = input.nextInt();
																boolean checkAgeValid = validation
																		.isValidAge(passengerAge);
																if (checkAgeValid)
																	ageFlag = false;
																else
																	System.out.println("Invalid Age!");
															}
															try {
																System.out.println(
																		"\n\n\t\tDiscount Fare for selected Bus : "
																				+ "Rs." + bookingService.displayFare(
																						passengerAge, busId)+"(per person)");
																searchFlag = false;
																sourceToDestinationFlag = false;
															} catch (CustomException e) {
																System.out.println(e.getMessage());
																searchFlag = true;
																busFarePageFlag = false;
															}
															break;
														case 2:
															boolean bookSeatFlag = true;
															System.out.println("Number of seats available : "
																	+ custService.checkSeatAvailability(busId));
															while (bookSeatFlag) {
																System.out.println("\n\t\t1.Book Seats");
																System.out.println("\n\t\t2.Go back");
																searchFlag = false;
																int bookingChoice = input.nextInt();
																switch (bookingChoice) {
																case 1:
																	bookSeatFlag = false;
																	System.out.println("Enter Number of seats to book");
																	int noOfBookingSeats = input.nextInt();
																	if(custService.checkSeatAvailability(busId)<noOfBookingSeats)
																	{
																		System.out.println("Sorry! The number of seats you have selected is unavailable");
																		break;
																	}
																	if(noOfBookingSeats>=10)
																	{
																		System.out.println("Sorry! You cannot book more than 9 seats at a time");
																		break;
																	}
																	float totalFare = 0;
																	int bookingId;
																	int age = 0;
																	ArrayList<String> passengerNames = new ArrayList<>();
																	
																	for (int i = 1; i <= noOfBookingSeats; i++) {
																		System.out.println(i+" "+ "Passenger Name");
																		passengerNames.add(input.next());
																		ageFlag = true;
																		while(ageFlag)
																		{
																		System.out.println(i+" "+ "Passenger Age");
								                                       
																		age = input.nextInt();
																		if(validation.isValidAge(age))
																			ageFlag = false;
																		else
																		{
																			System.out.println("Invalid Age!");
																			ageFlag = true; }
																		}
																		totalFare += bookingService.displayFare(age,
																				busId);
																	} // end_of_for_loop_i
																	System.out
																			.println("\n\t\tTotal Fare will be : " + totalFare);
																	boolean cardNumberFlag = true;
																	long cardNumber = 0;
																	while(cardNumberFlag)
																	{
																	System.out.println(
																			"\n\t\tEnter Debit or Credit Card Number");
									
																	 cardNumber = input.nextLong();
																	if(validation.isCardValid(cardNumber))
																		cardNumberFlag = false;
																	else
																	{
																		System.out.println("Invalid Card Number!");
																		cardNumberFlag = true;
																	}
																	}
																	boolean cvvFlag = true;
																	int cardCvv= 0;
																	while(cvvFlag)
																	{
																	System.out.println("\n\t\tEnter CVV");
																	
																	 cardCvv = input.nextInt();
																	if(validation.isValidCvv(cardCvv))
																	cvvFlag = false;
																	else
																	{
																		System.out.println("Invalid Cvv!");
																		cvvFlag = true;
																	}
																		
																	}
																	System.out.println(bookingService.bookSeat(
																			passengerNames, age, cardNumber, cardCvv,
																			busId, totalFare));
																	System.out.println("\n\t\t1.Generate Ticket");
																	System.out.println("\n\t\t2.Cancel Booking");
																	int ticketChoice = input.nextInt();
																	switch (ticketChoice) {
																	case 1:
																		searchFlag = false;
																		System.out.println("\n\t\tEnter your booking Id");
																		bookingId = input.nextInt();
																		System.out.println(bookingService
																				.generateTicket(busId, bookingId));
																		bookSeatFlag = false;

																		sourceToDestinationFlag = false;
																		break;
																	case 2:
																		System.out.println("\n\t\tEnter Booking Id");
																		bookingId = input.nextInt();
																		System.out.println(bookingService
																				.cancelBooking(bookingId, busId));
																		System.out.println(
																				"Amount successfully refunded=" + "Rs."
																						+ bookingService.refundMoney(
																								bookingId));
																		break;
																	}// end_of_switch_case_ticketChoice'
																	break;
																case 2:
																	busFarePageFlag = true;
																	bookSeatFlag = false;
																	break;

																}// end_of_switch_case_bookingChoice

															} // end_of_while_bookSeatFlag
															break;
														case 3:
															busFarePageFlag = false;
															searchFlag = true;
															break;
														}// end_of_switch_seatChoice
													} // end_of_switch_busFarePageFlag
												case 2:
													searchFlag = false;
												}// end_of_switch_busIdChoice
											} // end_of_tryblock
											catch (CustomException e) 
											{
												System.out.println(e.getMessage());
												sourceToDestinationFlag = true;
												break;
											} // end_of_catchblock
										} // end_of_while_searchFlag
									
									} // end_of_while_sourceToDestinationFlag
								case 3:
									System.out.println("Enter 1. for Departure Time/n2. for Arrival Time");
									int sortTimeChoice=input.nextInt();
									switch(sortTimeChoice)
									{
									case 1:
										custService.sortBusByDepartureTime(sourceStation,destinationStation);
										break;
									case 2:
										break;
									default:
										System.out.println("Invalid input");
									}
									break;
									
								case 4:
									passChangeFlag = false;
									loginScreenFlag = false;
									mainScreenFlag = true;
									break;
								}// end_of_switch_loginChoice
								break;
							} // end_of_while_passChangeFlag
						}
					}

				}
				break;
			case 3:
				System.exit(0);
			}// Choice_Switch
		} // Main_While

	}
}
