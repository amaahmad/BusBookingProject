package com.cg.web.obtrs.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.obtrs.entities.BusEntity;
import com.cg.web.obtrs.exception.CustomException;
import com.cg.web.obtrs.repositories.BusRepository;

@Service
public class BusServiceImpl implements BusService {

	@Autowired
	BusRepository busRepository;

	@Override
	public List<BusEntity> searchBus() throws CustomException {
		return busRepository.findAll();
	}

	public boolean isBusListEmpty() throws CustomException {
		if (busRepository.findAll() != null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public Optional<BusEntity> searchBusById(Integer busId) throws CustomException {

		return busRepository.findById(busId);
	}

	@Override
	public BusEntity updateBus(BusEntity bus) throws CustomException {
		return busRepository.save(bus);
	}

}
