package com.cg.web.obtrs.services;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.exception.CustomException;

public interface BookingService 
{
	 List<BookingEntity> getAllBooking() throws CustomException;
	
	 Optional<BookingEntity> getBookingById( Integer bookingId) throws CustomException;
	
	 boolean isBookingExists( Integer bookingId) throws CustomException;
	
	 BookingEntity addBooking(BookingEntity entity) throws CustomException;
	
	 boolean cancelBooking( Integer bookingId) throws CustomException;
}
