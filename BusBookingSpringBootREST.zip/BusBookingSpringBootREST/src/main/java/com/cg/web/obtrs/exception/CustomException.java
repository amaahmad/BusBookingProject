package com.cg.web.obtrs.exception;

public class CustomException extends RuntimeException
{

	public CustomException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

  public CustomException(String arg0)
   {
	   super(arg0);
   }
  
}
