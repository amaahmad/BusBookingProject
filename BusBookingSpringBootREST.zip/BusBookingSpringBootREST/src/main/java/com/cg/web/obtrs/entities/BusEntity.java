package com.cg.web.obtrs.entities;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Bus")
public class BusEntity implements Comparable<BusEntity>
{
	 @Id
	 @Column(name ="bus_id")
	  private int busId;
	 @Column(name ="source_station")
	  private String sourceStation;
	 @Column(name ="destination_station")
	  private String destinationStation;
	 @Column(name ="boarding_time")
	  private LocalDateTime boardingTime;
	 @Column(name ="drop_time")
	  private LocalDateTime dropTime;
	 @Column(name ="bus_type")
	  private String busType;
	  @Column(name = "total_seats")
	  private Integer totalSeats;
	  private Float fare;
       @Column(name ="seats_booked")
	  private int seatsBooked;
	  
	public BusEntity(int busId, String sourceStation, String destinationStation,LocalDateTime boardingTime, LocalDateTime dropTime, String busType, Integer totalSeats,
			Float fare, int seatsBooked) {
		super();
		this.busId=busId;
		this.sourceStation = sourceStation;
		this.destinationStation = destinationStation;
		this.busType = busType;
		this.fare = fare;
		this.totalSeats=totalSeats;
		this.boardingTime = boardingTime;
		this.dropTime = dropTime;
		this.seatsBooked= seatsBooked;
	}
	public BusEntity()
	{
		super();
	}

	public int getSeatsBooked() {
		return seatsBooked;
	}
	public void setSeatsBooked(int seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public String getSourceStation() {
		return sourceStation;
	}
	public void setSourceStation(String sourceStation) {
		this.sourceStation = sourceStation;
	}
	public String getDestinationStation() {
		return destinationStation;
	}
	public void setDestinationStation(String destinationStation) {
		this.destinationStation = destinationStation;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public Integer getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(Integer totalSeats) {
		this.totalSeats = totalSeats;
	}
	public Float getFare() {
		return fare;
	}
	public void setFare(Float fare) {
		this.fare = fare;
	}

	public LocalDateTime getBoardingTime() {
		return boardingTime;
	}
	public void setBoardingTime(LocalDateTime boardingTime) {
		this.boardingTime = boardingTime;
	}
	public LocalDateTime getDropTime() {
		return dropTime;
	}
	public void setDropTime(LocalDateTime dropTime) {
		this.dropTime = dropTime;
	}

	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	@Override
	public String toString() {
		DateTimeFormatter format1 = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a");  
		return "\n\t\tBus Id:" + busId +"\n"+"\n\t\tSource Station:"+ sourceStation+"\n"+ "\n\t\tDestination Station:" + destinationStation+"\n"
				+ "\n\t\tBoarding Time:" + boardingTime.format(format1)+"\n" + "\n\t\tDropTime:" + dropTime.format(format1) +"\n"+ "\n\t\tBus Type:" + busType +"\n"+ "\n\t\tTotal Seats:"
				+ totalSeats +"\n"+"\n\n";
	}
	
	public static final Comparator<BusEntity> departureComparator = new Comparator<BusEntity>()
	{
	    @Override
	    public int compare(BusEntity bus1, BusEntity bus2) {
	        return bus1.getBoardingTime().compareTo(bus2.getBoardingTime());
	    }
	};
	public static final Comparator<BusEntity>arrivalComparator = new Comparator<BusEntity>()
	{
	    @Override
	    public int compare(BusEntity bus1, BusEntity bus2) {
	        return bus1.getBoardingTime().compareTo(bus2.getBoardingTime());
	    }
	};
	@Override
	public int compareTo(BusEntity bus) {
		return this.busId-bus.busId;
	}
}
