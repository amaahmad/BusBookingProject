package com.cg.web.obtrs.services;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.web.obtrs.entities.BusEntity;
import com.cg.web.obtrs.exception.CustomException;

public interface BusService 
{
    List<BusEntity> searchBus() throws CustomException;
   
    boolean isBusListEmpty() throws CustomException;
   
    Optional<BusEntity> searchBusById( Integer busId) throws CustomException;
   
    BusEntity updateBus( BusEntity bus) throws CustomException;
   
}
