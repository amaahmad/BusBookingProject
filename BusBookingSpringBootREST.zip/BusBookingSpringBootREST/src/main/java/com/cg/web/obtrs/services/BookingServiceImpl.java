package com.cg.web.obtrs.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.exception.CustomException;
import com.cg.web.obtrs.repositories.BookingRepository;

@Service
public class BookingServiceImpl implements BookingService
{
	@Autowired
	BookingRepository bookingRepository;

	@Override
	public List<BookingEntity> getAllBooking() throws CustomException {
		return bookingRepository.findAll();
	}

	@Override
	public Optional<BookingEntity> getBookingById(Integer bookingId) throws CustomException {
		return bookingRepository.findById(bookingId);
	}

	@Override
	public BookingEntity addBooking(BookingEntity entity) throws CustomException {
		return bookingRepository.save(entity);
	}

	@Override
	public boolean cancelBooking(Integer bookingId) throws CustomException {
		bookingRepository.deleteById(bookingId);
		return true;
	}

	@Override
	public boolean isBookingExists(Integer bookingId) throws CustomException {
		if(bookingRepository.findById(bookingId).isPresent())
		return true;
		else
	    return false;
	}
	
	

}
