package com.cg.web.obtrs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.entities.BusEntity;
import com.cg.web.obtrs.repositories.BookingRepository;
import com.cg.web.obtrs.repositories.BusRepository;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class BusController {
	
	@Autowired
	private BusRepository busRepository;
	
	@Autowired
	private BookingRepository bookingRepository;
	
	@GetMapping("/bus")
	public List<BusEntity> getAllBus()
	{
		return busRepository.findAll();
	}
	@GetMapping("/bus{busId}")
	public Optional<BusEntity> getBus(@PathVariable Integer busId)
	{
		return busRepository.findById(busId);
	}
	@GetMapping("/booking")
	public List<BookingEntity> getAllBooking()
	{
		return bookingRepository.findAll();
	}
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/booking{bookingId}")
	public Optional<BookingEntity> getBooking(@PathVariable Integer bookingId)
	{
		return bookingRepository.findById(bookingId);
	}
	
	@PostMapping("/add")
	public BookingEntity addMovie(@RequestBody BookingEntity entity)
	{
		return bookingRepository.save(entity);
	}
	@DeleteMapping("/delete{bookingId}")
	public boolean cancelBooking(@PathVariable Integer bookingId)
	{
		bookingRepository.deleteById(bookingId);
		return true;
	}
	
	@PutMapping("/update")
	public BusEntity updateBus(@RequestBody BusEntity bus)
	{
		return busRepository.save(bus);
	}
	
}
