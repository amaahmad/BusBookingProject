package com.cg.web.obtrs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.entities.BusEntity;
import com.cg.web.obtrs.exception.CustomException;
import com.cg.web.obtrs.repositories.BookingRepository;
import com.cg.web.obtrs.repositories.BusRepository;
import com.cg.web.obtrs.services.BookingService;
import com.cg.web.obtrs.services.BusService;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class BusController {

	@Autowired
	private BusService busService;

	@Autowired
	private BookingService bookingService;

	@GetMapping("/bus")
	public List<BusEntity> getAllBus() throws CustomException {
		if (busService.isBusListEmpty() == false)
			return busService.searchBus();
		else
			throw new CustomException("No buses operating Currently");
	}

	@GetMapping("/bus{busId}")
	public Optional<BusEntity> getBus(@PathVariable Integer busId) {
		return busService.searchBusById(busId);
	}

	@GetMapping("/booking")
	public List<BookingEntity> getBookings() {
		return bookingService.getAllBooking();
	}

	@CrossOrigin("http://localhost:4200")
	@GetMapping("/booking{bookingId}")
	public Optional<BookingEntity> getBooking(@PathVariable Integer bookingId) throws CustomException {
		if (bookingService.isBookingExists(bookingId) == true)
			return bookingService.getBookingById(bookingId);
		else
			throw new CustomException("No Booking Found");
	}

	@PostMapping("/add")
	public BookingEntity addNewBooking(@RequestBody BookingEntity entity) {
		return bookingService.addBooking(entity);
	}

	@DeleteMapping("/delete{bookingId}")
	public boolean cancelBooking(@PathVariable Integer bookingId) {
		if (bookingService.isBookingExists(bookingId) == true) {
			bookingService.cancelBooking(bookingId);
			return true;
		} else
			throw new CustomException("No Booking Found");
	}

	@PutMapping("/update")
	public BusEntity updateBus(@RequestBody BusEntity bus) {
		return busService.updateBus(bus);
	}
}
