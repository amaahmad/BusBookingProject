package com.cg.obtrs.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ReportEntity {
	
	@Id
	private Integer busId;
	private Integer bookingId;
	private String passengerNames;
	private String sourceStation;
	private String destinationStation;
	private String boardingTime;
	private String dropTime;
	private String busType;
	private Float fare;
	private Integer seatsBooked;
	private Float totalFare;
	private String seatNo;
	public ReportEntity() {
		super();
	}
	public ReportEntity(Integer busId, Integer bookingId, String passengerNames, String sourceStation,
			String destinationStation, String boardingTime, String dropTime, String busType, Float fare,
			Integer seatsBooked, Float totalFare, String seatNo) {
		super();
		this.busId = busId;
		this.bookingId = bookingId;
		this.passengerNames = passengerNames;
		this.sourceStation = sourceStation;
		this.destinationStation = destinationStation;
		this.boardingTime = boardingTime;
		this.dropTime = dropTime;
		this.busType = busType;
		this.fare = fare;
		this.seatsBooked = seatsBooked;
		this.totalFare = totalFare;
		this.seatNo = seatNo;
	}
	public Integer getBusId() {
		return busId;
	}
	public void setBusId(Integer busId) {
		this.busId = busId;
	}
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public String getPassengerNames() {
		return passengerNames;
	}
	public void setPassengerNames(String passengerNames) {
		this.passengerNames = passengerNames;
	}
	public String getSourceStation() {
		return sourceStation;
	}
	public void setSourceStation(String sourceStation) {
		this.sourceStation = sourceStation;
	}
	public String getDestinationStation() {
		return destinationStation;
	}
	public void setDestinationStation(String destinationStation) {
		this.destinationStation = destinationStation;
	}
	public String getBoardingTime() {
		return boardingTime;
	}
	public void setBoardingTime(String boardingTime) {
		this.boardingTime = boardingTime;
	}
	public String getDropTime() {
		return dropTime;
	}
	public void setDropTime(String dropTime) {
		this.dropTime = dropTime;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public Float getFare() {
		return fare;
	}
	public void setFare(Float fare) {
		this.fare = fare;
	}
	public Integer getSeatsBooked() {
		return seatsBooked;
	}
	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}
	public Float getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(Float totalFare) {
		this.totalFare = totalFare;
	}
	public String getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}
	@Override
	public String toString() {
		return "ReportEntity [busId=" + busId + ", bookingId=" + bookingId + ", passengerNames=" + passengerNames
				+ ", sourceStation=" + sourceStation + ", destinationStation=" + destinationStation + ", boardingTime="
				+ boardingTime + ", dropTime=" + dropTime + ", busType=" + busType + ", fare=" + fare + ", seatsBooked="
				+ seatsBooked + ", totalFare=" + totalFare + ", seatNo=" + seatNo + "]";
	}
	

}
