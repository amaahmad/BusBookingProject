package com.cg.obtrs.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AdminEntity {

	@Id
	private int busId;

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public AdminEntity(int busId) {
		super();
		this.busId = busId;
	}

	public AdminEntity() {
		super();
	}

	@Override
	public String toString() {
		return "AdminDto [busId=" + busId + "]";
	}

}
