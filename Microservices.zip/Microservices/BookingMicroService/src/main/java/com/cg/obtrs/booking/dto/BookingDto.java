package com.cg.obtrs.booking.dto;

import java.math.BigInteger;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class BookingDto {

	//Booking details
	private BigInteger bookingId;
	private BigInteger busId;
	private float totalFare;
	private Date bookingDate;
    //Passenger details
	private String passengerNames;
	private Integer seatsBooked;
	private String seatNo;

	public BookingDto() {
		super();
	}

	public BookingDto(BigInteger busId, String passengerNames, Integer seatsBooked, float totalFare, BigInteger bookingId,
			String seatNo, Date bookingDate) {
		super();
		this.busId = busId;
		this.passengerNames = passengerNames;
		this.seatsBooked = seatsBooked;
		this.totalFare = totalFare;
		this.bookingId = bookingId;
		this.seatNo = seatNo;
		this.bookingDate = bookingDate;
	}

	public BigInteger getBusId() {
		return busId;
	}

	public void setBusId(BigInteger busId) {
		this.busId = busId;
	}

	public Integer getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public String getPassengerNames() {
		return passengerNames;
	}

	public void setPassengerNames(String passengerNames) {
		this.passengerNames = passengerNames;
	}

	public float getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(float totalFare) {
		this.totalFare = totalFare;
	}

	public BigInteger getBookingId() {
		return bookingId;
	}

	public void setBookingId(BigInteger bookingId) {
		this.bookingId = bookingId;
	}

	public String getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	@Override
	public String toString() {
		return "BookingDTO [busId=" + busId + ", passengerNames=" + passengerNames + ", seatsBooked=" + seatsBooked
				+ ", totalFare=" + totalFare + "]";
	}

}
