package com.cg.obtrs.booking.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.obtrs.booking.dao.BookingRepository;
import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.exception.CustomException;

@Service
public class BookingServiceImpl implements BookingService {
	@Autowired
	BookingRepository bookingRepository;

	final static Logger logger = Logger.getLogger(BookingServiceImpl.class);

	@Override
	public List<BookingEntity> getAllBooking() throws CustomException {
		return bookingRepository.findAll();
	}

	@Override
	public BookingEntity getBookingById(BigInteger bookingId) throws CustomException {
		Optional<BookingEntity> optional = bookingRepository.findById(bookingId);
		if (optional.isPresent()) {
			BookingEntity booking = optional.get();
			return booking;
		} else {
			logger.error("BOOKING NOT FOUND WITH THE BOOKING ID = " + bookingId);
			throw new CustomException("Sorry, Booking Not Found");
		}
	}

	@Override
	public BookingEntity addBooking(BookingEntity entity) throws CustomException {
		return bookingRepository.save(entity);
	}

	@Override
	public boolean cancelBooking(BigInteger bookingId) throws CustomException {
		Optional<BookingEntity> optional = bookingRepository.findById(bookingId);
		if (optional.isPresent()) {
			bookingRepository.deleteById(bookingId);
			return true;
		} else {
			logger.error("BOOKING NOT FOUND WITH THE BOOKING ID = " + bookingId);
			throw new CustomException("Sorry, Booking Not Found");
		}
	}

	@Override
	public List<BookingEntity> getBookingByBusId(BigInteger busId) throws CustomException {

		List<BookingEntity> bookingList = bookingRepository.getBookingByBusId(busId);
		if (bookingList.isEmpty()) {
			logger.info("Sorry!!! No Booking under this busId");
			throw new CustomException("Sorry!!! No Booking under this busId");
		}
		return bookingList;
	}

}
