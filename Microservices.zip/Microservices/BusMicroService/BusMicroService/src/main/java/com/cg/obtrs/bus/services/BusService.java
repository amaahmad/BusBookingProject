package com.cg.obtrs.bus.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.obtrs.bus.entities.BusEntity;
import com.cg.obtrs.bus.exception.CustomException;

public interface BusService 
{
    List<BusEntity> searchBus(String sourceStation,String destinationStation) throws CustomException;
    
    List<String> findAllSourceStation() throws CustomException;
    
    List<String> findAllDestinationStation() throws CustomException;
   
    BusEntity getBusById( BigInteger busId) throws CustomException;
   
    BusEntity updateBus( BusEntity bus) throws CustomException;

	List<BusEntity> getAllBus() throws CustomException;

	boolean deleteBus(BigInteger busId) throws CustomException;

	BusEntity addBus(BusEntity bus) throws CustomException ;
    
}
