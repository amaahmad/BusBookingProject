package com.cg.obtrs.bus.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.obtrs.bus.entities.BusEntity;
import com.cg.obtrs.bus.exception.CustomException;
import com.cg.obtrs.bus.services.BusService;

@RestController
@RequestMapping("/bus")
@CrossOrigin("http://localhost:4200")
public class BusController {

	@Autowired
	private BusService busService;
	final static Logger logger = Logger.getLogger(BusController.class);

	@Autowired
	RestTemplate restTemplate;

	@PostMapping("/new")
	public BusEntity addNewBus(@RequestBody BusEntity bus) {
		return busService.addBus(bus);
	}

	@GetMapping("/searchbus/{sourceStation}+{destinationStation}")
	public ResponseEntity<List<BusEntity>> searchForBus(@PathVariable String sourceStation,
			@PathVariable String destinationStation) {
		List<BusEntity> busList = busService.searchBus(sourceStation, destinationStation);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(busList, HttpStatus.OK);
		return response;
	}

	@GetMapping("/allsource")
	public ResponseEntity<List<String>> findAllSourceStation() {
		List<String> sourceList = busService.findAllSourceStation();
		ResponseEntity<List<String>> response = new ResponseEntity<>(sourceList, HttpStatus.OK);
		return response;
	}

	@GetMapping("/alldestination")
	public ResponseEntity<List<String>> findAllDestinationStation() {
		List<String> destinationList = busService.findAllDestinationStation();
		ResponseEntity<List<String>> response = new ResponseEntity<>(destinationList, HttpStatus.OK);
		return response;
	}

	@GetMapping("/busbyid/{busId}")
	public ResponseEntity<BusEntity> getBus(@PathVariable BigInteger busId) {
		BusEntity bus = busService.getBusById(busId);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	@GetMapping("/buses")
	public ResponseEntity<List<BusEntity>> getAllBus() {
		List<BusEntity> bus = busService.getAllBus();
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	@PutMapping("/update")
	public ResponseEntity<BusEntity> updateBus(@RequestBody BusEntity entity) {
		BusEntity bus = busService.updateBus(entity);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		logger.info("BUS WITH THE BUS ID = " + entity.getBusId() + " UPDATED.");
		return response;

	}

	@DeleteMapping("/delete/{busId}")
	public boolean deleteBus(@PathVariable BigInteger busId) {
		boolean flag = busService.deleteBus(busId);
		logger.info("BUS REMOVED WITH THE BUS ID = " + busId);
		return true;
	}
}
